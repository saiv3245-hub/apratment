# owner.py — Backend หน้าหลักเจ้าของหอ; ไม่มีตัวเลขห้องหรือรายชื่อสมมติในฟังก์ชันนี้
# นำเครื่องมือ Flask มาใช้: Blueprint รวมเส้นทาง, jsonify ส่งข้อมูล, render_template เปิด HTML
from flask import Blueprint, jsonify, redirect, render_template, session
# owner_api_required มาจาก common.py ตรวจบัญชีและเปิด/ปิดการเชื่อมต่อให้ API นี้
from common import owner_api_required
# owner_bp เป็นตัวแปรของเรา; login.py ใช้ register_blueprint นำเส้นทางในนี้เข้าเว็บ
owner_bp = Blueprint("owner", __name__)
# สอง @route ให้ทั้ง /owner และ /owner.html เปิดผ่านฟังก์ชันเดียวกัน
@owner_bp.route("/owner")
@owner_bp.route("/owner.html")
def owner_page():
    # ตรวจ Session ก่อนเปิดหน้า; ยังไม่ Login จึงย้ายกลับ /
    if "user_id" not in session:
        return redirect("/")
    # role ใน Session ต้องเป็น admin หรือ owner; ไม่ใช่การซ่อนปุ่มอย่างเดียว
    if session.get("role") not in ("admin", "owner"):
        return "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", 403
    # เปิดโครงหน้า owner.html ก่อน จากนั้น js/owner.js จะขอข้อมูลสรุปอีกคำขอ
    return render_template("owner.html")
# GET เส้นทางนี้ส่ง JSON ให้ JavaScript ไม่ได้ส่ง HTML
@owner_bp.get("/api/owner/dashboard")
# ตัวครอบตรวจสิทธิ์ในฐานข้อมูลจริง และจัดการ transaction/ข้อผิดพลาดให้
@owner_api_required
def owner_dashboard(cursor):
    # COUNT(*) นับทุกแถว; FILTER นับเฉพาะแถวที่ตรงเงื่อนไข; AS ตั้งชื่อให้ Python อ่านผล
    # upper(btrim(status)) ตัดช่องว่างหัวท้ายและทำตัวใหญ่; สถานะ AVAILABLE ใช้นับห้องว่าง
    cursor.execute("""
        SELECT COUNT(*) AS total_rooms,
               COUNT(*) FILTER (WHERE upper(btrim(status)) = 'AVAILABLE') AS available_rooms
        FROM public.room
    """)
    # fetchone อ่านหนึ่งแถว; ชุดนับ COUNT คืนแถวเดียวและได้ศูนย์เมื่อตารางไม่มีรายการ
    room_summary = cursor.fetchone()
    # นับผู้เช่าที่เปิดใช้งานข้อมูล ไม่ใช่นับสัญญาหรือยืนยันว่าผู้เช่าทุกคนยังพักอยู่
    cursor.execute("SELECT COUNT(*) AS active_tenants FROM public.tenants WHERE is_active = true")
    tenant_summary = cursor.fetchone()
    # บิลค้างในโค้ดนี้คือครบกำหนดก่อนวันนี้ มียอดชำระน้อยกว่ายอดเต็ม และไม่ระบุ PAID
    # CURRENT_DATE คือวันที่ของฐานข้อมูล; COALESCE(...,0) ใช้ 0 แทน NULL; <> คือไม่เท่ากัน
    cursor.execute("""
        SELECT COUNT(*) AS overdue_bills
        FROM public.invoices
        WHERE due_date < CURRENT_DATE
          AND COALESCE(amount_paid, 0) < COALESCE(total_amount, 0)
          AND upper(btrim(payment_status)) <> 'PAID'
    """)
    invoice_summary = cursor.fetchone()
    # อ่านใบแจ้งหนี้ล่าสุด ไม่ใช่ตารางธุรกรรมชำระเงินแยก; total_amount คือยอดทั้งบิล ไม่ใช่ยอดที่จ่ายจริง
    # i/c/r/t เป็นชื่อย่อตาราง; concat_ws รวมชื่อและนามสกุลด้วยช่องว่าง; ::text ส่งเงินเป็นข้อความ
    # JOIN ... ON เชื่อมใบแจ้งหนี้ → สัญญา → ห้อง/ผู้เช่า; ต้องมีแถวที่ตรงกันจึงแสดง
    # ORDER BY ... DESC เรียงเดือนใหม่ก่อน แล้วรหัสมากก่อน; LIMIT 5 แสดงไม่เกินห้ารายการ
    cursor.execute("""
        SELECT i.invoice_id, r.room_number, concat_ws(' ', t.first_name, t.last_name) AS tenant_name,
               i.total_amount::text AS total_amount, i.payment_status
        FROM public.invoices i
        JOIN public.rental_contracts c ON c.contract_id = i.contract_id
        JOIN public.room r ON r.room_id = c.room_id
        JOIN public.tenants t ON t.tenant_id = c.tenant_id
        ORDER BY i.billing_month DESC, i.invoice_id DESC
        LIMIT 5
    """)
    # fetchall คืนรายการหลายแถวให้ js/owner.js วนสร้างตาราง
    invoices = cursor.fetchall()
    # อ่านงานแจ้งซ่อมที่ยังไม่ COMPLETED/CANCELLED; NOT IN คือไม่อยู่ในชุดค่านั้น
    # CASE WHEN กำหนดลำดับความเร่งด่วนเอง: URGENT มาก่อน HIGH/NORMAL/LOW
    # เลข 1–5 ตรงนี้เป็นน้ำหนักเรียงลำดับ ไม่ใช่ข้อมูลผู้เช่าหรือจำนวนงานซ่อม
    cursor.execute("""
        SELECT m.request_id, m.request_number, r.room_number, m.title, m.priority, m.status
        FROM public.maintenance_requests m
        JOIN public.room r ON r.room_id = m.room_id
        WHERE upper(btrim(m.status)) NOT IN ('COMPLETED', 'CANCELLED')
        ORDER BY CASE upper(btrim(m.priority))
            WHEN 'URGENT' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'NORMAL' THEN 3 WHEN 'LOW' THEN 4 ELSE 5
        END, m.request_id DESC
        LIMIT 5
    """)
    repairs = cursor.fetchall()
    # รวมผลทุกคำสั่งใน JSON เดียว; ชื่อด้านซ้ายต้องตรงกับ data.total_rooms ฯลฯ ใน js/owner.js
    return jsonify(
        total_rooms=room_summary["total_rooms"],
        available_rooms=room_summary["available_rooms"],
        active_tenants=tenant_summary["active_tenants"],
        overdue_bills=invoice_summary["overdue_bills"],
        invoices=invoices,
        repairs=repairs
    )
