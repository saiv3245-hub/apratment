# common.py — เครื่องมือตรวจข้อมูล/สิทธิ์/ข้อผิดพลาดที่ Backend หลายหน้าใช้ร่วมกัน
# การทำงาน: ตรวจ Session → อ่านสิทธิ์จาก user → เรียกงานจริง → commit หรือ rollback → ปิด connection
# re ตรวจหรือแก้ข้อความตามรูปแบบ เช่น หาตัวเลขในเบอร์โทร
import re
# secrets ให้เครื่องมือที่เหมาะกับข้อมูลลับ ในไฟล์นี้ใช้เปรียบเทียบรหัส CSRF
import secrets
# Decimal เก็บเลขฐานสิบให้เหมาะกับเงิน; InvalidOperation คือข้อผิดพลาดตอนแปลงเป็น Decimal
from decimal import Decimal, InvalidOperation
# wraps เก็บชื่อและรายละเอียดของฟังก์ชันเดิมไว้ เมื่อเราเขียนฟังก์ชันครอบมัน
from functools import wraps
# ใช้ psycopg2.Error แยกข้อผิดพลาดฐานข้อมูลออกจากข้อผิดพลาดประเภทอื่น
import psycopg2
# jsonify ส่งข้อมูลกลับเป็น JSON; request คือคำขอรอบนี้; session คือข้อมูลจำผู้ใช้ข้ามหน้า
from flask import jsonify, request, session
# RealDictCursor ทำให้ผล SELECT เรียกด้วยชื่อช่องได้ เช่น account["role"]
from psycopg2.extras import RealDictCursor
# เรียกฟังก์ชันจาก database.py; ไฟล์นี้ไม่ต้องเขียนรหัสผ่านฐานข้อมูลซ้ำ
from database import get_connection
# class สร้างชนิดข้อมูลของเรา; (Exception) หมายถึงต่อยอดจากข้อผิดพลาดของ Python
# ApiError ใช้แจ้งปัญหาที่เราคาดไว้ เช่น ข้อมูลไม่ครบหรือไม่มีสิทธิ์
class ApiError(Exception):
    # __init__ ทำงานตอนสร้าง ApiError; self คือตัวที่กำลังสร้าง; status=400 คือค่าเริ่มต้น
    def __init__(self, message, status=400):
        # super() เรียกส่วนของ Exception เดิม ให้เก็บข้อความผิดพลาดตามกลไกของ Python
        super().__init__(message)
        # self.message กับ self.status เก็บข้อความและรหัส HTTP ไว้ให้ except ใช้ตอบหน้าเว็บ
        self.message = message
        self.status = status
# ตรวจข้อความแล้วคืนค่าที่ตัดช่องว่างหัวท้าย; ชื่อฟังก์ชันและชื่อพารามิเตอร์เป็นชื่อของเรา
# data คือชุดข้อมูล; key คือชื่อช่อง; label คือชื่อภาษาไทย; required=True บังคับว่าต้องมีข้อความ
def clean_text(data, key, label, max_length, required=True):
    # get(key, "") อ่านตามชื่อ ถ้าไม่มีช่องนี้ให้ใช้ข้อความว่างแทน
    value = data.get(key, "")
    # isinstance(value, str) ตรวจว่าเป็นข้อความ ไม่รับรายการหรือชุดข้อมูลมาแทนข้อความ
    if not isinstance(value, str):
        # raise หยุดทางปกติแล้วส่งข้อผิดพลาด; f"...{label}..." เติมค่าตัวแปรลงในข้อความ
        raise ApiError(f"{label}ไม่ถูกต้อง")
    # strip() ตัดช่องว่างหัวท้าย ไม่ลบช่องว่างระหว่างชื่อกับนามสกุล
    value = value.strip()
    # and ต้องจริงทั้งสองด้าน; not value คือข้อความว่างหลังตัดช่องว่างแล้ว
    if required and not value:
        raise ApiError(f"กรุณากรอก{label}")
    # len() นับความยาว; > ตรวจว่ามากกว่าขีดจำกัดหรือไม่
    if len(value) > max_length:
        raise ApiError(f"{label}ยาวเกิน {max_length} ตัวอักษร")
    # return คืนข้อความที่ผ่านการตรวจให้ room.py หรือ tenant.py ใช้ต่อ
    return value
# แปลงเป็นจำนวนเต็มและตรวจขอบเขต; minimum/maximum เป็น None หมายถึงไม่ตรวจด้านนั้น
def parse_int(value, label, minimum=None, maximum=None):
    # try ทดลองคำสั่งที่อาจล้มเหลว; except เลือกจัดการชนิดข้อผิดพลาดที่คาดไว้
    try:
        # int() แปลงเป็นจำนวนเต็ม; ระวัง: ถ้ารับเลขทศนิยมจริงจาก JSON จะตัดเศษได้ จึงยังควรตรวจชนิดเพิ่มก่อนใช้จริง
        number = int(value)
    # TypeError เช่นส่ง None มา; ValueError เช่นส่งข้อความที่ไม่ใช่เลขมา
    except (TypeError, ValueError):
        raise ApiError(f"{label}ต้องเป็นจำนวนเต็ม")
    # is not None คือมีค่าขอบเขตให้ตรวจ; < คือเล็กกว่า; ไม่ใช้ if minimum เพราะค่าศูนย์ก็อาจเป็นขอบเขตได้
    if minimum is not None and number < minimum:
        raise ApiError(f"{label}ต่ำกว่าค่าที่กำหนด")
    if maximum is not None and number > maximum:
        raise ApiError(f"{label}สูงกว่าค่าที่กำหนด")
    return number
# ตรวจจำนวนเงินด้วยชื่อช่องที่ผู้เรียกกำหนด ฟังก์ชันเดียวใช้ทั้งค่าเช่าและเงินประกัน
def parse_money(data, key, label):
    value = clean_text(data, key, label, 20)
    try:
        # สร้าง Decimal จากข้อความโดยตรง เพื่อไม่ผ่านเลขทศนิยมฐานสองก่อน
        amount = Decimal(value)
    except InvalidOperation:
        raise ApiError(f"{label}ต้องเป็นตัวเลข")
    # is_finite() ไม่รับ NaN หรือ Infinity ซึ่งไม่ใช่ยอดเงินปกติ
    if not amount.is_finite():
        raise ApiError(f"{label}ต้องเป็นตัวเลขปกติ")
    # or คือผิดเงื่อนไขอย่างใดอย่างหนึ่งก็พอ; จำกัดยอดให้ตรงช่วงเงินที่โค้ดนี้รองรับ
    if amount < 0 or amount > Decimal("99999999.99"):
        raise ApiError(f"{label}อยู่นอกช่วงที่รองรับ")
    # as_tuple().exponent บอกตำแหน่งทศนิยม; ต่ำกว่า -2 คือมีทศนิยมเกินสองตำแหน่งในรูปที่รับมา
    if amount.as_tuple().exponent < -2:
        raise ApiError(f"{label}ใส่ทศนิยมได้ไม่เกิน 2 ตำแหน่ง")
    return amount
# ตรวจเบอร์โทรเบื้องต้นเท่านั้น ไม่ได้ยืนยันว่าเป็นเบอร์ที่มีผู้ใช้จริง
def validate_phone(value, label):
    # r"..." เก็บรูปแบบข้อความโดยไม่แปล backslash; [^0-9] คือสิ่งที่ไม่ใช่เลข 0–9; sub ลบออก
    digits = re.sub(r"[^0-9]", "", value)
    # 9 <= len(digits) <= 15 ตรวจความยาวสองด้าน; โค้ดนี้นับแต่เลข จึงยังไม่ได้ปฏิเสธตัวอักษรที่ปนมา
    if not 9 <= len(digits) <= 15:
        raise ApiError(f"{label}ต้องมีตัวเลข 9–15 หลัก")
# อ่านข้อมูล JSON ที่ JavaScript ส่งมา ไม่ใช่ request.form ของฟอร์ม Login
def get_json_data():
    # silent=True ให้คืน None เมื่ออ่าน JSON ไม่สำเร็จ แล้วเราค่อยแจ้งข้อความของเราเอง
    data = request.get_json(silent=True)
    # dict คือชุดชื่อคู่กับค่า เช่น {"room_number": "101"}; ไม่รับรายการหรือข้อความเดี่ยว
    if not isinstance(data, dict):
        raise ApiError("รูปแบบข้อมูลไม่ถูกต้อง")
    return data
# ฟังก์ชันครอบ API: ตรวจสิทธิ์และฐานข้อมูลให้ก่อน แล้วจึงเรียกงานของห้องหรือผู้เช่า
# เมื่อนำไปใช้เป็น @owner_api_required จะไม่ต้องเขียนชุดตรวจนี้ซ้ำทุกหน้า
def owner_api_required(function):
    # @wraps(function) เก็บชื่อฟังก์ชันปลายทางไว้ ไม่ให้ Flask เห็นทุกเส้นทางเป็นชื่อ wrapped เหมือนกัน
    @wraps(function)
    # *args รับค่าตามลำดับ; **kwargs รับค่าที่ระบุชื่อ เช่น room_id จาก URL; ส่งต่อให้ฟังก์ชันจริงภายหลัง
    def wrapped(*args, **kwargs):
        # ตรวจชื่อ user_id ใน Session ก่อน แต่ยังต้องไปตรวจบัญชีปัจจุบันในฐานข้อมูลอีกครั้ง
        if "user_id" not in session:
            # jsonify(error=...) ให้ JS อ่าน data.error; 401 คือยังไม่มีการเข้าสู่ระบบ
            return jsonify(error="กรุณาเข้าสู่ระบบใหม่"), 401
        # GET อ่านข้อมูล; HEAD ขอเฉพาะส่วนหัว; วิธีอื่นในงานนี้เปลี่ยนข้อมูล จึงต้องตรวจ CSRF
        if request.method not in ("GET", "HEAD"):
            # headers คือข้อมูลกำกับคำขอ; JS ใส่ X-CSRF-Token มากับ fetch ตอนเพิ่ม/แก้ไข/ลบ
            sent_token = request.headers.get("X-CSRF-Token", "")
            # รหัสฝั่งเบราว์เซอร์ต้องตรงกับรหัสที่ Session ของบัญชีนั้นจำไว้
            session_token = session.get("csrf_token", "")
            # compare_digest เปรียบเทียบรหัสลับ; short-circuit ของ or หยุดเมื่อพบเงื่อนไขจริงทางซ้ายแล้ว
            if not sent_token or not session_token or not secrets.compare_digest(sent_token, session_token):
                # 403 คือไม่อนุญาต; รหัส CSRF ไม่ถูกต้องไม่ได้แปลว่าฐานข้อมูลเสีย
                return jsonify(error="หน้าเว็บหมดอายุ กรุณารีเฟรชแล้วลองใหม่"), 403
        # เริ่มด้วย None เพื่อให้ส่วน finally ตรวจได้ว่าเปิดการเชื่อมต่อสำเร็จหรือยัง
        conn = None
        cursor = None
        try:
            # เปิด connection สำหรับคำขอนี้; common.py เรียก database.py ไม่ได้เป็นฐานข้อมูลอีกตัว
            conn = get_connection()
            # cursor ใช้ส่ง SQL; cursor_factory เปลี่ยนรูปแบบผลลัพธ์จากลำดับช่องเป็นชื่อช่อง
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            # SELECT อ่าน role และ is_active จากบัญชีจริง; WHERE เลือก user_id ของ Session; LIMIT 1 ไม่เกินหนึ่งแถว
            # public คือกลุ่มตาราง; "user" เป็นชื่อตารางที่ต้องใส่คำพูด; %s รับค่าจาก tuple ที่ส่งแยกไว้
            cursor.execute("""
                SELECT role, is_active
                FROM public."user"
                WHERE user_id = %s
                LIMIT 1
            """, (session["user_id"],))
            # fetchone() ได้หนึ่งแถวหรือ None; ผลที่นี่เป็น dict จึงใช้ account["is_active"] ได้
            account = cursor.fetchone()
            # บัญชีถูกลบหรือปิดภายหลัง Login ก็ต้องหยุดคำขอนี้ ไม่ใช้ role เก่าใน Session ตัดสินอย่างเดียว
            if not account or not account["is_active"]:
                raise ApiError("บัญชีนี้ไม่สามารถใช้งานได้", 403)
            # str แปลงเป็นข้อความ; strip ตัดช่องว่าง; lower ทำตัวเล็กก่อนเทียบสิทธิ์
            role = str(account["role"]).strip().lower()
            if role not in ("admin", "owner"):
                raise ApiError("คุณไม่มีสิทธิ์จัดการข้อมูล", 403)
            # transaction คือชุดคำสั่งฐานข้อมูลที่ยืนยันด้วย commit หรือยกเลิกด้วย rollback ร่วมกัน
    # เรียกฟังก์ชันงานจริง พร้อม cursor และค่าจาก URL; ฟังก์ชันงานจริงใช้ cursor นี้ใน transaction เดียวกัน
            result = function(cursor, *args, **kwargs)
            # commit ยืนยันการแก้ไข; ถ้าล้มเหลวก่อนจุดนี้ except จะ rollback แทน
            conn.commit()
            # ส่งผลจากงานจริง เช่นรายการ JSON หรือข้อความบันทึกสำเร็จ กลับไปให้ Flask
            return result
        # รับ ApiError ที่เราโยนไว้ด้วย raise ไม่ถือว่าเป็นระบบพัง
        except ApiError as error:
            if conn:
                # rollback ยกเลิกงานฐานข้อมูลของคำขอนี้ที่ยังไม่ commit
                conn.rollback()
            return jsonify(error=error.message), error.status
        # ข้อผิดพลาดจาก PostgreSQL/psycopg2 เช่น SQL ไม่ตรงคอลัมน์ หรือเชื่อมต่อไม่ได้
        except psycopg2.Error as error:
            if conn:
                conn.rollback()
            # รายละเอียดอยู่ใน Terminal ส่วนหน้าเว็บได้ข้อความทั่วไป; ไม่ควรเผยแพร่ log ที่มีข้อมูลส่วนบุคคล
            print("Database error:", error)
            return jsonify(error="ทำรายการกับฐานข้อมูลไม่สำเร็จ"), 500
        # รับข้อผิดพลาดอื่นที่ไม่ได้เข้ากลุ่มก่อนหน้า; 500 คือเซิร์ฟเวอร์ทำงานไม่สำเร็จ
        except Exception as error:
            if conn:
                conn.rollback()
            print("Server error:", error)
            return jsonify(error="เกิดข้อผิดพลาดในระบบ"), 500
        # finally ทำทุกกรณี รวมกรณี return จึงปิด cursor/connection ได้เมื่อจบคำขอ
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    # คืนฟังก์ชัน wrapped ไปแทนฟังก์ชันเดิมในเส้นทาง ไม่ใช่สั่งให้มันทำงานตอน import
    return wrapped
