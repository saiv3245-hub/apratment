# tenant.py — ข้อมูลผู้เช่า แยกจากบัญชีเข้าสู่ระบบ; หน้าเว็บคือ tenants.html และสคริปต์คือ js/tenants.js
# re ใช้ตรวจรูปแบบอีเมล ไม่ใช่การส่งอีเมลยืนยัน
import re
# Blueprint รวมเส้นทาง; request รับคำขอ; session จำผู้ใช้; jsonify ส่งข้อมูลให้ JS
from flask import Blueprint, jsonify, redirect, render_template, request, session
# ตัวตรวจข้อมูลและตัวครอบ API อยู่ common.py ใช้ร่วมกับหน้าห้องพัก
from common import ApiError, clean_text, get_json_data, owner_api_required, parse_int, validate_phone
# tenant_bp เป็นกลุ่มงานจัดการผู้เช่า ไม่ใช่หน้า /tenant ของผู้เช่าเข้าสู่ระบบเอง
tenant_bp = Blueprint("tenant", __name__)
# เปิดหน้า tenants.html สำหรับเจ้าของหอ; การอ่านข้อมูลจริงเกิดที่ API ด้านล่าง
@tenant_bp.route("/tenants.html")
def tenants_page():
    # ไม่มี user_id ใน Session ต้องกลับไป Login ก่อน
    if "user_id" not in session:
        return redirect("/")
    # หน้า UI ตรวจสิทธิ์จาก Session; API จะตรวจบัญชีจากฐานข้อมูลปัจจุบันผ่าน common.py อีกครั้ง
    if session.get("role") not in ("admin", "owner"):
        return "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", 403
    return render_template("tenants.html")
# API อ่านรายการบัญชีให้ช่องเลือก user_id ไม่สร้างบัญชีใหม่ในเส้นทางนี้
@tenant_bp.get("/api/tenant-users")
# @owner_api_required ตรวจสิทธิ์และส่ง cursor เข้ามาให้ฟังก์ชัน
@owner_api_required
def tenant_users_api(cursor):
    # request.args อ่านค่าหลัง ?; ตอนแก้ไขส่งรหัสผู้เช่าปัจจุบันเพื่อให้ยังเลือกบัญชีเดิมได้
    current_tenant_id = request.args.get("tenant_id", "").strip()
    # รูปแบบ ค่าแรก if เงื่อนไข else ค่าหลัง คือ if แบบสั้น; ถ้าไม่ส่งให้ใช้ 0 เป็นรหัสสมมติว่าไม่มีผู้เช่าปัจจุบัน
    # ข้อสังเกตของโค้ดเดิม: JS ส่ง tenant_id=0 ตอนเพิ่ม แต่ parse_int(...,1) ไม่รับ 0 จึงอาจหยุดตรงนี้
    current_tenant_id = parse_int(current_tenant_id, "รหัสผู้เช่า", 1) if current_tenant_id else 0
    # u/t เป็นชื่อย่อของตาราง user/tenants; role ต้องเป็น tenant
    # NOT EXISTS แปลว่ายังไม่มีผู้เช่าคนใดผูกบัญชีนี้; หรือ EXISTS บัญชีเดิมของผู้เช่าที่กำลังแก้
    # ผลจึงอาจรวมบัญชีเดิมที่ปิดใช้งานไว้ด้วย เพื่อให้ดูและแก้ข้อมูลเดิมได้; ORDER BY เรียงชื่อบัญชี
    cursor.execute("""
        SELECT u.user_id, u.user_name, u.is_active
        FROM public."user" u
        WHERE lower(btrim(u.role)) = 'tenant'
        AND (
            (u.is_active = true AND NOT EXISTS(
                SELECT 1 FROM public.tenants t WHERE t.user_id = u.user_id
            ))
            OR EXISTS(
                SELECT 1 FROM public.tenants t
                WHERE t.user_id = u.user_id AND t.tenant_id = %s
            )
        )
        ORDER BY u.user_name
    """, (current_tenant_id,))
    # fetchall คืนรายการ; jsonify(items=...) ให้ JS อ่าน data.items เพื่อสร้าง option
    return jsonify(items=cursor.fetchall())
# รวมการตรวจฟอร์มไว้ฟังก์ชันเดียว ใช้ทั้งเพิ่มและแก้ไขผู้เช่า
def validate_tenant_data(data):
    # {ชื่อ:ค่า} คือ dict; payload เป็นชื่อที่เราตั้งให้ข้อมูลที่ตรวจแล้ว ไม่ใช่ชนิดข้อมูลพิเศษ
    payload = {
        # clean_text ตัดช่องว่างและตรวจความยาว; ชื่อด้านซ้ายตรงกับ name ใน input และช่องฐานข้อมูล
        "tenant_code": clean_text(data, "tenant_code", "รหัสผู้เช่า", 20),
        # user_id เป็นเลขบัญชีที่เลือก ไม่ใช่ชื่อผู้เช่า; parse_int บังคับเป็นรหัสบวก
        "user_id": parse_int(data.get("user_id"), "บัญชีผู้ใช้งาน", 1),
        "first_name": clean_text(data, "first_name", "ชื่อ", 100),
        "last_name": clean_text(data, "last_name", "นามสกุล", 100),
        # ช่องนี้ตรวจเพียงข้อความ/ความยาว ยังไม่ได้ตรวจเลขหลักสุดท้ายหรือยืนยันตัวบุคคล
        "national_id": clean_text(data, "national_id", "เลขประจำตัวประชาชน", 20),
        "phone": clean_text(data, "phone", "เบอร์โทรศัพท์", 20),
        "email": clean_text(data, "email", "อีเมล", 150),
        "address": clean_text(data, "address", "ที่อยู่", 5000),
        "emergency_contact_name": clean_text(data, "emergency_contact_name", "ชื่อผู้ติดต่อฉุกเฉิน", 150),
        "emergency_contact_phone": clean_text(data, "emergency_contact_phone", "เบอร์ผู้ติดต่อฉุกเฉิน", 20)
    }
    # ตรวจจำนวนหลักของเบอร์ตาม validate_phone ใน common.py ไม่ได้โทรไปยืนยันเบอร์
    validate_phone(payload["phone"], "เบอร์โทรศัพท์")
    validate_phone(payload["emergency_contact_phone"], "เบอร์ผู้ติดต่อฉุกเฉิน")
    # re.fullmatch ให้ข้อความทั้งก้อนตรงรูปแบบ; [^\s@]+ คืออักขระที่ไม่ใช่ช่องว่างหรือ @ อย่างน้อยหนึ่งตัว
    # ส่วน @ และ \. บังคับรูปแบบคล้ายอีเมล; เป็นเพียงกติกาเบื้องต้น ไม่รับรองว่าอีเมลนี้มีอยู่จริง
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", payload["email"]):
        raise ApiError("รูปแบบอีเมลไม่ถูกต้อง")
    # option จาก HTML ส่ง "true"/"false" เป็นข้อความ จึงต้องตรวจและแปลงก่อนใช้กับ boolean ในฐานข้อมูล
    if data.get("is_active") not in ("true", "false"):
        raise ApiError("สถานะข้อมูลผู้เช่าไม่ถูกต้อง")
    # == คืนค่าจริง/เท็จ; payload["is_active"] จึงกลายเป็น True/False ไม่ใช่ข้อความเดิม
    payload["is_active"] = data["is_active"] == "true"
    return payload
# ตรวจบัญชีที่ผูกกับผู้เช่า; current_tenant_id=0 ใช้ตอนเพิ่มเพื่อไม่ต้องยกเว้นใคร
def validate_tenant_user(cursor, user_id, current_tenant_id=0):
    # SELECT ตรวจว่ามีบัญชีจริง ไม่เชื่อ user_id ที่ส่งจากช่องเลือกเพียงอย่างเดียว
    cursor.execute("""
        SELECT role, is_active
        FROM public."user"
        WHERE user_id = %s
        LIMIT 1
    """, (user_id,))
    user = cursor.fetchone()
    # fetchone ได้ None หมายถึงไม่พบบัญชี ให้โยน ApiError ไปยัง common.py
    if not user:
        raise ApiError("ไม่พบบัญชีผู้ใช้งานที่เลือก")
    # strip/lower ปรับข้อความก่อนตรวจสิทธิ์ ต้องเป็นผู้เช่า ไม่เอาบัญชีเจ้าของหอมาผูก
    if str(user["role"]).strip().lower() != "tenant":
        raise ApiError("บัญชีที่เลือกต้องเป็นสิทธิ์ผู้เช่า")
    # บัญชีที่ปิดใช้งานจะใช้ได้เฉพาะเมื่อเป็นบัญชีเดิมของผู้เช่าที่กำลังแก้
    if not user["is_active"]:
        cursor.execute("""
            SELECT 1 FROM public.tenants
            WHERE tenant_id = %s AND user_id = %s
            LIMIT 1
        """, (current_tenant_id, user_id))
        if not cursor.fetchone():
            raise ApiError("บัญชีผู้ใช้งานที่เลือกถูกปิดใช้งาน")
    # <> ตัดคนปัจจุบันออกจากการตรวจ; user_id เดียวห้ามผูกกับผู้เช่าคนอื่นตามกติกานี้
    cursor.execute("""
        SELECT 1 FROM public.tenants
        WHERE user_id = %s AND tenant_id <> %s
        LIMIT 1
    """, (user_id, current_tenant_id))
    if cursor.fetchone():
        raise ApiError("บัญชีนี้เชื่อมกับผู้เช่ารายอื่นแล้ว", 409)
# ตรวจข้อมูลซ้ำจากสามช่อง; ไม่ได้ตรวจว่าชื่อคนจริงหรือรหัสประจำตัวถูกต้อง
def validate_tenant_duplicates(cursor, payload, current_tenant_id=0):
    # list ของ tuple: แต่ละชุดเก็บชื่อคอลัมน์ ค่าที่ตรวจ และข้อความที่จะแจ้ง
    checks = [
        ("tenant_code", payload["tenant_code"], "รหัสผู้เช่านี้มีอยู่แล้ว"),
        ("national_id", payload["national_id"], "เลขประจำตัวประชาชนนี้มีอยู่แล้ว"),
        ("email", payload["email"], "อีเมลผู้เช่านี้มีอยู่แล้ว")
    ]
    # for วนแต่ละชุดแล้วแยกใส่ column/value/message; ไม่ต้องเขียน SELECT ซ้ำสามชุด
    for column, value, message in checks:
        # {column} มาจากรายชื่อคงที่ด้านบนเท่านั้น; ห้ามเปลี่ยนไปรับชื่อคอลัมน์จากผู้ใช้แล้วต่อ SQL โดยตรง
        # %s ใช้ส่งค่าจริงแยกจาก SQL; LIMIT 1 พอรู้ว่ามีข้อมูลซ้ำก็หยุดค้น
        cursor.execute(f"""
            SELECT 1 FROM public.tenants
            WHERE lower(btrim({column})) = lower(%s) AND tenant_id <> %s
            LIMIT 1
        """, (value, current_tenant_id))
        if cursor.fetchone():
            raise ApiError(message, 409)
# GET อ่านตารางผู้เช่า; POST เพิ่มคนใหม่; ไม่ใช่ระบบสมัครบัญชีสาธารณะ
@tenant_bp.route("/api/tenants", methods=["GET", "POST"])
@owner_api_required
def tenants_api(cursor):
    if request.method == "GET":
        # q และ status ต้องตรงชื่อที่ js/tenants.js ตั้งใน URLSearchParams
        search = request.args.get("q", "").strip()
        status = request.args.get("status", "").strip()
        # conditions รวมเงื่อนไข SQL; values รวมค่าทดแทน %s ตามลำดับ
        conditions = []
        values = []
        if search:
            # ILIKE ค้นโดยไม่แยกตัวใหญ่เล็ก; concat_ws รวมชื่อกับนามสกุลเพื่อค้นทั้งชื่อเต็มได้
            conditions.append("""
                (tenant_code ILIKE %s OR concat_ws(' ', first_name, last_name) ILIKE %s
                OR phone ILIKE %s OR email ILIKE %s)
            """)
            # % รอบคำค้นหมายถึงส่วนก่อน/หลังอะไรก็ได้; extend เพิ่มสี่ค่าตาม %s สี่ตำแหน่ง
            values.extend([f"%{search}%", f"%{search}%", f"%{search}%", f"%{search}%"])
        # ข้อความว่างคือทุกสถานะ; "false" ไม่ใช่ข้อความว่าง จึงยังเข้ามากรองสถานะปิดใช้งานได้
        if status:
            if status not in ("true", "false"):
                raise ApiError("สถานะผู้เช่าไม่ถูกต้อง")
            conditions.append("is_active = %s")
            values.append(status == "true")
        # join รวมด้วย AND เมื่อมีตัวกรอง; ถ้าไม่มีใช้ SQL ว่างเพื่ออ่านทุกคน
        where_sql = " WHERE " + " AND ".join(conditions) if conditions else ""
        # รายการหลักส่งเฉพาะข้อมูลสำหรับตาราง ไม่ส่งเลขประจำตัว/ที่อยู่ทั้งหมดจนกดดูรายละเอียด
        cursor.execute(f"""
            SELECT tenant_id, tenant_code, first_name, last_name, phone, email, is_active
            FROM public.tenants
            {where_sql}
            ORDER BY tenant_code, tenant_id
        """, values)
        return jsonify(items=cursor.fetchall())
    # POST รับ JSON ตรวจทุกช่องก่อนเขียนลงฐานข้อมูล
    data = get_json_data()
    payload = validate_tenant_data(data)
    # ล็อกงานเขียนตารางชั่วคราวจนจบ transaction เพื่อช่วยกันการเพิ่มเลขหรือข้อมูลซ้ำในโค้ดชุดนี้
    cursor.execute("LOCK TABLE public.tenants IN EXCLUSIVE MODE")
    validate_tenant_duplicates(cursor, payload)
    # ต้องมีบัญชี tenant อยู่แล้ว; ฟังก์ชันนี้ไม่เพิ่มแถวใน user ให้อัตโนมัติ
    validate_tenant_user(cursor, payload["user_id"])
    # MAX + 1 คำนวณรหัสเองภายใต้การล็อก ไม่ใช่เลขจาก sequence ของ PostgreSQL
    cursor.execute("SELECT COALESCE(MAX(tenant_id), 0) + 1 AS next_id FROM public.tenants")
    tenant_id = cursor.fetchone()["next_id"]
    # INSERT INTO เพิ่มแถวตามชื่อคอลัมน์; VALUES ต้องตรงลำดับ tuple ด้านล่าง
    # RETURNING tenant_id อ่านรหัสแถวใหม่; common.py เป็นผู้ commit หรือ rollback ทั้งคำขอ
    cursor.execute("""
        INSERT INTO public.tenants
        (tenant_id, tenant_code, user_id, first_name, last_name, national_id, phone, email,
         address, emergency_contact_name, emergency_contact_phone, is_active)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING tenant_id
    """, (
        tenant_id, payload["tenant_code"], payload["user_id"], payload["first_name"],
        payload["last_name"], payload["national_id"], payload["phone"], payload["email"],
        payload["address"], payload["emergency_contact_name"],
        payload["emergency_contact_phone"], payload["is_active"]
    ))
    # ส่ง 201 เมื่อสร้างข้อมูลใหม่ และส่ง tenant_id ให้หน้าเว็บทราบ
    return jsonify(message="เพิ่มผู้เช่าเรียบร้อย", tenant_id=cursor.fetchone()["tenant_id"]), 201
# <int:tenant_id> อ่านรหัสจาก URL; GET ดูหนึ่งคน, PUT แก้หนึ่งคน, DELETE ลบหนึ่งคน
@tenant_bp.route("/api/tenants/<int:tenant_id>", methods=["GET", "PUT", "DELETE"])
@owner_api_required
def tenant_item_api(cursor, tenant_id):
    # อ่านรายละเอียดทุกช่องให้ฟอร์ม; LEFT JOIN เก็บผู้เช่าไว้แม้ไม่พบบัญชีที่ตรง ต่างจาก JOIN ปกติ
    # WHERE เลือกคนเดียว; LIMIT 1 ไม่เกินหนึ่งแถว; user_name ใช้แสดงชื่อบัญชีในหน้าดูข้อมูล
    cursor.execute("""
        SELECT t.tenant_id, t.tenant_code, t.user_id, t.first_name, t.last_name, t.national_id,
               t.phone, t.email, t.address, t.emergency_contact_name, t.emergency_contact_phone,
               t.is_active, u.user_name
        FROM public.tenants t
        LEFT JOIN public."user" u ON u.user_id = t.user_id
        WHERE t.tenant_id = %s
        LIMIT 1
    """, (tenant_id,))
    tenant_data = cursor.fetchone()
    if not tenant_data:
        raise ApiError("ไม่พบข้อมูลผู้เช่านี้", 404)
    # GET จบตรงนี้ จึงไม่มีการเขียนหรือลบข้อมูล
    if request.method == "GET":
        return jsonify(item=tenant_data)
    if request.method == "DELETE":
        # EXISTS ตรวจประวัติสัญญาหรือแจ้งซ่อม; มีอย่างใดอย่างหนึ่งก็ป้องกันการลบ
        cursor.execute("""
            SELECT EXISTS(SELECT 1 FROM public.rental_contracts WHERE tenant_id = %s)
            OR EXISTS(SELECT 1 FROM public.maintenance_requests WHERE tenant_id = %s) AS is_used
        """, (tenant_id, tenant_id))
        if cursor.fetchone()["is_used"]:
            raise ApiError("ลบผู้เช่านี้ไม่ได้ เพราะมีประวัติสัญญาหรือแจ้งซ่อม ใช้การปิดใช้งานแทน", 409)
        # ลบแถวใน tenants เท่านั้น ไม่ลบบัญชีใน user และไม่ลบประวัติอื่นตามเอง
        cursor.execute("DELETE FROM public.tenants WHERE tenant_id = %s", (tenant_id,))
        return jsonify(message="ลบข้อมูลผู้เช่าเรียบร้อย")
    # PUT ตรวจข้อมูลใหม่เหมือนตอนเพิ่ม ก่อนแก้แถวเดิม
    data = get_json_data()
    payload = validate_tenant_data(data)
    cursor.execute("LOCK TABLE public.tenants IN EXCLUSIVE MODE")
    # ตอนตรวจซ้ำส่ง tenant_id ปัจจุบันไปด้วย เพื่อไม่ถือว่าข้อมูลเดิมของคนนี้ซ้ำกับตัวเอง
    validate_tenant_duplicates(cursor, payload, tenant_id)
    validate_tenant_user(cursor, payload["user_id"], tenant_id)
    # UPDATE แก้ข้อมูลคนเดิม; SET กำหนดค่าใหม่; WHERE จำกัดรหัสผู้เช่า
    # is_active ในที่นี้คือสถานะข้อมูลผู้เช่า ไม่ได้แก้ user.is_active ของบัญชีเข้าสู่ระบบ
    cursor.execute("""
        UPDATE public.tenants
        SET tenant_code = %s, user_id = %s, first_name = %s, last_name = %s,
            national_id = %s, phone = %s, email = %s, address = %s,
            emergency_contact_name = %s, emergency_contact_phone = %s, is_active = %s
        WHERE tenant_id = %s
    """, (
        payload["tenant_code"], payload["user_id"], payload["first_name"], payload["last_name"],
        payload["national_id"], payload["phone"], payload["email"], payload["address"],
        payload["emergency_contact_name"], payload["emergency_contact_phone"],
        payload["is_active"], tenant_id
    ))
    # ข้อความสำเร็จส่งกลับหลัง common.py ยืนยัน transaction ไม่ใช่การเพิ่มแถวสมมติใน HTML
    return jsonify(message="แก้ไขข้อมูลผู้เช่าเรียบร้อย")
