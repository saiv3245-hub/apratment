# database.py — เก็บการตั้งค่าเชื่อมฐานข้อมูล; ค่าจริงเดิมคงไว้ ไม่ได้เปลี่ยนรหัสผ่าน
# psycopg2 คือเครื่องมือให้ Python ติดต่อ PostgreSQL ไม่ใช่โปรแกรม pgAdmin
import psycopg2
# def สร้างฟังก์ชัน; ชื่อ get_connection เราตั้งเอง ไฟล์อื่นเรียกเมื่อต้องใช้ฐานข้อมูล
def get_connection():
    # connect() เปิดการเชื่อมต่อใหม่; conn เป็นตัวแปรเก็บการเชื่อมต่อนี้ ไม่ใช่ข้อมูลทุกตาราง
    conn = psycopg2.connect(
        # host คือเครื่องที่ฐานข้อมูลทำงานอยู่; localhost คือเครื่องเดียวกับที่รัน Python
        host="localhost",
        # database ต้องตรงกับชื่อฐานข้อมูลใน PostgreSQL ชื่อไฟล์สำรองไม่จำเป็นต้องเหมือนกัน
        database="apartment_F&B",
        # user ตรงนี้เป็นบัญชีเข้า PostgreSQL ไม่ใช่ผู้เช่าหรือเจ้าของหอในตาราง user
        user="postgres",
        # password เป็นรหัสผ่าน PostgreSQL ของเครื่องคุณ ต้องลบหรือปิดบังก่อนส่งไฟล์ให้คนอื่น
        password="1234",
        # port คือช่องทางที่บริการ PostgreSQL รับการเชื่อมต่อ ไม่ใช่ port 5000 ของหน้าเว็บ Flask
        port="5432"
    )
    # return ส่ง conn กลับให้ผู้เรียกใช้; ผู้เรียกเป็นคน commit/rollback และ close() หลังใช้งาน
    return conn
