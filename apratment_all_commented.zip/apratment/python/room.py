# room.py — Backend หน้า room.html; รับคำขอจาก js/room.js แล้วอ่าน/เพิ่ม/แก้ไข/ลบ PostgreSQL
# เปิดระบบด้วย python python/login.py ไม่ต้องรันไฟล์ room.py แยก
# Blueprint รวมเส้นทางของห้องพัก; jsonify ส่งข้อมูล; redirect ย้ายหน้า; render_template เปิด HTML; request/session มาจาก Flask
from flask import Blueprint, jsonify, redirect, render_template, request, session
# ฟังก์ชันเหล่านี้อยู่ common.py ใช้ร่วมกัน ไม่ต้องเขียนตัวตรวจข้อมูลและเชื่อมต่อซ้ำในไฟล์นี้
from common import ApiError, clean_text, get_json_data, owner_api_required, parse_int, parse_money
# ชื่อ room_bp ตั้งเอง; Blueprint("room", __name__) จัดกลุ่มเส้นทาง ยังไม่เปิดเซิร์ฟเวอร์เอง
room_bp = Blueprint("room", __name__)
# {...} ที่มีแต่ค่าเป็น set สำหรับตรวจสมาชิก; ไม่ใช่ dict แบบชื่อ:ค่า
ROOM_STATUS = {"AVAILABLE", "OCCUPIED", "MAINTENANCE"}
# GET /room.html เปิดหน้าห้องพัก; Python login.py ลงทะเบียน room_bp ให้แล้ว
@room_bp.route("/room.html")
def room_page():
    # ถ้ายังไม่มี Session ให้กลับหน้าเข้าสู่ระบบ
    if "user_id" not in session:
        return redirect("/")
    # เช็กสิทธิ์ก่อนเปิดหน้า; API ด้านล่างจะอ่านสิทธิ์ปัจจุบันจากฐานข้อมูลซ้ำอีกชั้น
    if session.get("role") not in ("admin", "owner"):
        return "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", 403
    # คืนโครง HTML; ข้อมูลตารางค่อยให้ js/room.js ขอจาก /api/rooms
    return render_template("room.html")
# เส้นทางเดียวรับสองวิธี: GET อ่านรายการ, POST เพิ่มห้อง
@room_bp.route("/api/rooms", methods=["GET", "POST"])
# ตัวครอบใน common.py ตรวจสิทธิ์ เปิด cursor และจัดการ commit/rollback ให้
@owner_api_required
# cursor ถูกส่งมาจากตัวครอบ ไม่ใช่ข้อมูลที่ผู้ใช้กรอก
def rooms_api(cursor):
    if request.method == "GET":
        # request.args รับค่าหลัง ? ใน URL; q, floor, status ต้องตรงกับ params ที่ JS ส่ง
        search = request.args.get("q", "").strip()
        floor = request.args.get("floor", "").strip()
        status = request.args.get("status", "").strip()
        # conditions เก็บเงื่อนไข SQL; values เก็บค่าที่ใช้แทน %s โดยต้องเรียงลำดับตรงกัน
        conditions = []
        values = []
        if search:
            # append เพิ่มหนึ่งเงื่อนไข; ILIKE ค้นหาข้อความโดยไม่แยกตัวใหญ่เล็ก
            conditions.append("(room_number ILIKE %s OR room_type ILIKE %s)")
            # extend เพิ่มสองค่าลงรายการ; % รอบคำค้นใช้แทนข้อความก่อน/หลัง ต่างจาก %s ที่รอรับค่า
            values.extend([f"%{search}%", f"%{search}%"])
        # ใส่ตัวกรองชั้นเฉพาะเมื่อกรอกมา เพื่อให้ช่องว่างหมายถึงทุกชั้น
        if floor:
            conditions.append("floor = %s")
            # parse_int ตรวจชั้นตามกติกา 1–999 ในโค้ดนี้ ไม่ใช่ข้อบังคับของภาษา Python
            values.append(parse_int(floor, "ชั้น", 1, 999))
        if status:
            # not in ตรวจว่าค่าที่ส่งมาไม่อยู่ใน set สถานะที่ยอมรับ
            if status not in ROOM_STATUS:
                raise ApiError("สถานะห้องไม่ถูกต้อง")
            conditions.append("status = %s")
            values.append(status)
        # เขียนเงื่อนไขแบบสั้น: มี conditions จึงต่อ WHERE; join เชื่อมแต่ละเงื่อนไขด้วย AND
        where_sql = " WHERE " + " AND ".join(conditions) if conditions else ""
        # f"""...""" คือข้อความหลายบรรทัดที่เติม {where_sql}; where_sql สร้างจากรูปแบบที่กำหนดไว้ ไม่รับ SQL จากผู้ใช้
        # SELECT เลือกช่อง; ::text แปลงเงินเป็นข้อความ; COALESCE เลือก description หรือข้อความว่างเมื่อเป็น NULL
        # AS description ตั้งชื่อผลลัพธ์; ORDER BY เรียงชั้นแล้วหมายเลขห้องและรหัส; values ส่งแยกเพื่อแทน %s
        cursor.execute(f"""
            SELECT room_id, room_number, floor, room_type, monthly_rent::text, deposit_amount::text,
                   status, COALESCE(description, '') AS description
            FROM public.room
            {where_sql}
            ORDER BY floor, room_number, room_id
        """, values)
        # fetchall() ได้รายการแถวทั้งหมด; jsonify(items=...) ส่งเป็น {"items": [...]} ให้ JS วนสร้างตาราง
        return jsonify(items=cursor.fetchall())
    # หลังจบทาง GET เหลือทาง POST; อ่าน JSON จาก fetch ไม่ใช่ request.form
    data = get_json_data()
    # clean_text ตรวจข้อความจำเป็นและความยาวตามช่องที่ระบุ
    room_number = clean_text(data, "room_number", "หมายเลขห้อง", 20)
    floor = parse_int(data.get("floor"), "ชั้น", 1, 999)
    room_type = clean_text(data, "room_type", "ประเภทห้อง", 50)
    # parse_money ตรวจยอดไม่ติดลบและทศนิยมไม่เกินสองตำแหน่ง
    monthly_rent = parse_money(data, "monthly_rent", "ค่าเช่าต่อเดือน")
    deposit_amount = parse_money(data, "deposit_amount", "เงินประกัน")
    status = clean_text(data, "status", "สถานะห้อง", 20)
    # False ตัวท้ายทำให้รายละเอียดไม่บังคับกรอก ต่างจากช่องข้อความข้างบน
    description = clean_text(data, "description", "รายละเอียดเพิ่มเติม", 5000, False)
    if status not in ROOM_STATUS:
        raise ApiError("สถานะห้องไม่ถูกต้อง")
    # LOCK TABLE กันงานเขียนอื่นชั่วคราวจนจบ transaction เพื่อให้ตรวจซ้ำ/หาเลขถัดไปต่อกันได้
    # การล็อกทั้งตารางอาจทำให้ผู้ใช้อื่นรอ เหมาะกับการเข้าใจโค้ดเดิม ไม่ใช่วิธีที่ขยายระบบได้ดีที่สุด
    cursor.execute("LOCK TABLE public.room IN EXCLUSIVE MODE")
    # SELECT 1 ตรวจว่ามีหมายเลขซ้ำหรือไม่; lower(btrim(...)) ไม่สนช่องว่างหัวท้ายและตัวใหญ่เล็ก
    cursor.execute("""
        SELECT 1 FROM public.room
        WHERE lower(btrim(room_number)) = lower(%s)
        LIMIT 1
    """, (room_number,))
    # พบอย่างน้อยหนึ่งแถวให้ส่ง 409 แปลว่าขัดกับข้อมูลที่มีอยู่แล้ว
    if cursor.fetchone():
        raise ApiError("หมายเลขห้องนี้มีอยู่แล้ว", 409)
    # MAX หารหัสมากที่สุด; COALESCE(..., 0) ให้เริ่มจาก 0 เมื่อตารางว่าง แล้ว +1
    # นี่คือการคำนวณรหัสเอง ไม่ใช่ sequence; การล็อกด้านบนจึงสำคัญ และยังต้องดู default/กฎจริงของฐานข้อมูล
    cursor.execute("SELECT COALESCE(MAX(room_id), 0) + 1 AS next_id FROM public.room")
    # ["next_id"] อ่านตามชื่อผลลัพธ์ที่ตั้งด้วย AS ใน SQL
    room_id = cursor.fetchone()["next_id"]
    # INSERT INTO เพิ่มหนึ่งแถว; รายชื่อช่องต้องตรงกับ VALUES และค่าที่ส่งตามลำดับ
    # RETURNING room_id คืนรหัสของแถวที่เพิ่ม; description or None เปลี่ยนข้อความว่างเป็น NULL ในฐานข้อมูล
    cursor.execute("""
        INSERT INTO public.room
        (room_id, room_number, floor, room_type, monthly_rent, deposit_amount, status, description)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING room_id
    """, (room_id, room_number, floor, room_type, monthly_rent, deposit_amount, status, description or None))
    # 201 คือสร้างรายการใหม่; common.py จะ commit ก่อนส่งผลนี้ออกไปจริง
    return jsonify(message="เพิ่มห้องพักเรียบร้อย", room_id=cursor.fetchone()["room_id"]), 201
# <int:room_id> รับเลขรหัสจาก URL; PUT แก้ไข; DELETE ลบ ไม่เกี่ยวกับชื่อไฟล์ HTML
@room_bp.route("/api/rooms/<int:room_id>", methods=["PUT", "DELETE"])
@owner_api_required
def room_item_api(cursor, room_id):
    # ล็อกงานเขียนทั้งตารางเพื่อตรวจข้อมูลและแก้ไขในรอบเดียวกัน
    cursor.execute("LOCK TABLE public.room IN SHARE ROW EXCLUSIVE MODE")
    # FOR UPDATE ล็อกแถวที่พบจน transaction จบ ไม่ได้แก้ข้อมูลด้วยตัวมันเอง
    cursor.execute("SELECT room_id FROM public.room WHERE room_id = %s FOR UPDATE", (room_id,))
    # ถ้าหารหัสไม่พบ ให้คืน 404 ไม่ทำเหมือนลบหรือแก้ไขสำเร็จ
    if not cursor.fetchone():
        raise ApiError("ไม่พบห้องพักนี้", 404)
    if request.method == "DELETE":
        # EXISTS ได้จริง/เท็จตามว่ามีประวัติหรือไม่; OR คือมีในตารางใดตารางหนึ่งก็ถือว่าใช้งานอยู่
        cursor.execute("""
            SELECT EXISTS(SELECT 1 FROM public.rental_contracts WHERE room_id = %s)
            OR EXISTS(SELECT 1 FROM public.maintenance_requests WHERE room_id = %s) AS is_used
        """, (room_id, room_id))
        # ป้องกันลบห้องที่มีสัญญาหรือแจ้งซ่อมอยู่ เพื่อเก็บความเชื่อมโยงของประวัติ
        if cursor.fetchone()["is_used"]:
            raise ApiError("ลบห้องนี้ไม่ได้ เพราะมีประวัติสัญญาหรือแจ้งซ่อม", 409)
        # DELETE FROM ลบเฉพาะแถวที่ตรง room_id; ถ้าไม่มี WHERE จะลบทุกห้อง
        cursor.execute("DELETE FROM public.room WHERE room_id = %s", (room_id,))
        return jsonify(message="ลบห้องพักเรียบร้อย")
    # กรณี PUT อ่านและตรวจข้อมูลใหม่เหมือนตอนเพิ่ม ไม่เชื่อค่าจากหน้าเว็บทันที
    data = get_json_data()
    room_number = clean_text(data, "room_number", "หมายเลขห้อง", 20)
    floor = parse_int(data.get("floor"), "ชั้น", 1, 999)
    room_type = clean_text(data, "room_type", "ประเภทห้อง", 50)
    monthly_rent = parse_money(data, "monthly_rent", "ค่าเช่าต่อเดือน")
    deposit_amount = parse_money(data, "deposit_amount", "เงินประกัน")
    status = clean_text(data, "status", "สถานะห้อง", 20)
    description = clean_text(data, "description", "รายละเอียดเพิ่มเติม", 5000, False)
    if status not in ROOM_STATUS:
        raise ApiError("สถานะห้องไม่ถูกต้อง")
    # <> หมายถึงไม่เท่ากัน; ตรวจหมายเลขซ้ำโดยเว้นห้องที่กำลังแก้เอง
    cursor.execute("""
        SELECT 1 FROM public.room
        WHERE lower(btrim(room_number)) = lower(%s) AND room_id <> %s
        LIMIT 1
    """, (room_number, room_id))
    if cursor.fetchone():
        raise ApiError("หมายเลขห้องนี้มีอยู่แล้ว", 409)
    # จะเปลี่ยนไปว่างหรือปิดปรับปรุงต้องตรวจสัญญา ACTIVE ก่อน กติกานี้เขียนไว้ในโปรแกรม
    if status != "OCCUPIED":
        # upper แปลงสถานะเป็นตัวใหญ่; LIMIT 1 เพียงตรวจว่ามีสัญญาที่ยังใช้งานอยู่หรือไม่
        cursor.execute("""
            SELECT 1 FROM public.rental_contracts
            WHERE room_id = %s AND upper(btrim(contract_status)) = 'ACTIVE'
            LIMIT 1
        """, (room_id,))
        if cursor.fetchone():
            raise ApiError("ห้องนี้มีสัญญาเช่าที่กำลังใช้งานอยู่ จึงเปลี่ยนสถานะไม่ได้", 409)
    # UPDATE แก้แถวเดิม; SET ระบุค่าที่เปลี่ยน; WHERE จำกัดห้องเดียว; ค่าทั้งหมดส่งแยกจาก SQL
    cursor.execute("""
        UPDATE public.room
        SET room_number = %s, floor = %s, room_type = %s, monthly_rent = %s,
            deposit_amount = %s, status = %s, description = %s
        WHERE room_id = %s
    """, (room_number, floor, room_type, monthly_rent, deposit_amount, status, description or None, room_id))
    # ส่งข้อความสำเร็จให้ JS โหลดรายการใหม่ โดยไม่ได้สร้างหน้าหรือข้อมูลตัวอย่าง
    return jsonify(message="แก้ไขข้อมูลห้องพักเรียบร้อย")
