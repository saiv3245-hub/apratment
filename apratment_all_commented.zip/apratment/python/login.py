# import เรียกเครื่องมือมาใช้; os จัดการเส้นทางไฟล์; secrets สร้างค่าสุ่มที่เดายาก
import os
import secrets
# from ... import ... เลือกเฉพาะเครื่องมือที่ต้องการจาก Flask
from flask import Flask, jsonify, redirect, render_template, request, send_from_directory, session
# เครื่องมือสร้างค่าเก็บรหัสผ่านและตรวจรหัสผ่าน โดยไม่ต้องถอดกลับเป็นข้อความเดิม
from werkzeug.security import check_password_hash, generate_password_hash
# get_connection คือฟังก์ชันที่เราเขียนใน database.py ไม่ใช่คำสั่งของ Flask
from database import get_connection
# Blueprint คือกลุ่มเส้นทางของระบบ; *_bp เป็นชื่อตัวแปรที่เราตั้งในแต่ละไฟล์
from owner import owner_bp
from room import room_bp
from tenant import tenant_bp
# __file__ คือไฟล์นี้; abspath หาเส้นทางเต็ม; dirname สองครั้งย้อนจาก python/login.py ไปโฟลเดอร์หลัก
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# สร้างเว็บ Flask; __name__ ระบุโมดูลนี้; template_folder บอกตำแหน่งที่เก็บ HTML
app = Flask(__name__, template_folder=ROOT_DIR)
# สุ่มกุญแจตรวจความถูกต้องของ Session; เปิด Python ใหม่จะต้อง Login ใหม่
app.secret_key = secrets.token_hex(32)
# คุกกี้คือข้อมูลที่เบราว์เซอร์เก็บและส่งกลับมา; HttpOnly กัน JS อ่านคุกกี้ Session โดยตรง
app.config["SESSION_COOKIE_HTTPONLY"] = True
# SameSite=Lax จำกัดการส่งคุกกี้บางกรณีจากเว็บไซต์อื่น ไม่ได้แทนการตรวจ CSRF ทั้งหมด
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
# จำกัดข้อมูลที่ส่งมาในหนึ่งคำขอไว้ประมาณ 1 MB ไม่ใช่ขนาดฐานข้อมูล
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024
# register_blueprint นำเส้นทางจากแต่ละส่วนมาต่อเป็นเว็บเดียวกัน
app.register_blueprint(owner_bp)
app.register_blueprint(room_bp)
app.register_blueprint(tenant_bp)
# @app.route ผูกที่อยู่เว็บกับฟังก์ชัน; <path:filename> รับเส้นทางไฟล์หลัง /css/
@app.route("/css/<path:filename>")
# def ประกาศฟังก์ชัน; filename เป็นชื่อที่เราตั้งไว้รับค่าจากเส้นทางด้านบน
# : เริ่มชุดคำสั่ง และบรรทัดที่เยื้องเข้าไปคือคำสั่งภายในฟังก์ชัน
def css_files(filename):
    # return ส่งผลกลับ; join ต่อเส้นทาง; send_from_directory ส่งไฟล์จากโฟลเดอร์ที่ระบุ
    return send_from_directory(os.path.join(ROOT_DIR, "css"), filename)
# หลักการเดียวกัน แต่ส่งไฟล์จากโฟลเดอร์ js
@app.route("/js/<path:filename>")
def js_files(filename):
    return send_from_directory(os.path.join(ROOT_DIR, "js"), filename)
# ส่งรูปภาพจากโฟลเดอร์ image
@app.route("/image/<path:filename>")
def image_files(filename):
    return send_from_directory(os.path.join(ROOT_DIR, "image"), filename)
# / คือหน้าแรก; GET ใช้เปิดหน้า; POST ใช้รับข้อมูลจากฟอร์มเข้าสู่ระบบ
@app.route("/", methods=["GET", "POST"])
def login():
    # if ตรวจเงื่อนไข; == เปรียบเทียบค่า ส่วน = ใช้กำหนดค่าให้ตัวแปร
    if request.method == "POST":
        # request.form รับข้อมูลตาม name ใน HTML; get คืน "" ถ้าไม่มี; strip ตัดช่องว่างหัวท้าย
        username = request.form.get("username", "").strip()
        # ไม่ strip รหัสผ่าน เพราะช่องว่างอาจเป็นส่วนหนึ่งของรหัสที่ผู้ใช้ตั้ง
        password = request.form.get("password", "")
        # not กลับเงื่อนไข; or ผ่านเมื่ออย่างน้อยหนึ่งฝั่งเป็นจริง; len นับความยาว
        if not username or not password or len(username) > 100 or len(password) > 256:
            # redirect ย้ายหน้า; ?error=invalid ส่งรหัสแจ้งเตือนให้ JS ไม่ส่งรหัสผ่าน
            return redirect("/?error=invalid")
        # None หมายถึงยังไม่มีค่า กำหนดไว้เพื่อให้ finally ตรวจและปิดได้
        conn = None
        cursor = None
        # try ครอบคำสั่งที่อาจเกิดข้อผิดพลาด แล้วให้ except จัดการ
        try:
            # conn เป็นชื่อที่เราตั้งเก็บการเชื่อมต่อ; cursor ใช้ส่ง SQL และอ่านผล
            conn = get_connection()
            cursor = conn.cursor()
            # execute ส่ง SQL; SELECT เลือกข้อมูล; FROM ระบุตาราง; WHERE กำหนดเงื่อนไข
            # lower แปลงเป็นตัวเล็ก; btrim ตัดช่องว่างหัวท้าย; LIMIT 1 ขอผลไม่เกินหนึ่งแถว
            # public คือชื่อกลุ่มตาราง; "user" ครอบด้วยคำพูดเพราะชื่อชนกับคำพิเศษของ PostgreSQL
            # %s รับค่าจาก (username,); จุลภาคทำให้เป็นชุดข้อมูลหนึ่งค่า ไม่ใช่ข้อความธรรมดา
            cursor.execute("""
                SELECT user_id, user_name, password_hash, role, is_active
                FROM public."user"
                WHERE lower(btrim(user_name)) = lower(%s)
                LIMIT 1
            """, (username,))
            # fetchone อ่านหนึ่งแถว; cursor แบบนี้คืนข้อมูลตามลำดับ SELECT โดยเริ่มนับจาก 0
            user = cursor.fetchone()
            # is None ตรวจว่าไม่พบแถวที่ตรงเงื่อนไข
            if user is None:
                return redirect("/?error=invalid")
            # user[4] คือ is_active; False หมายถึงบัญชีถูกปิด
            if not user[4]:
                return redirect("/?error=inactive")
            # str แปลงเป็นข้อความ; user[2] คือค่ารหัสผ่านที่อ่านจากฐานข้อมูล
            stored_password = str(user[2])
            # startswith ตรวจส่วนต้น; สองคำนี้เป็นรูปแบบ Hash ที่ระบบนี้รองรับ
            is_hash = stored_password.startswith(("scrypt:", "pbkdf2:"))
            if is_hash:
                # ตรวจรหัสที่พิมพ์กับ Hash ไม่ใช่เปรียบเทียบข้อความสองตัวตรง ๆ
                password_ok = check_password_hash(stored_password, password)
            else:
                # รองรับรหัสเก่าที่เก็บเป็นข้อความเท่านั้น บัญชีใหม่ไม่ควรเก็บแบบนี้
                # encode แปลงข้อความเป็นไบต์; compare_digest เปรียบเทียบค่าแบบเหมาะกับข้อมูลลับ
                password_ok = secrets.compare_digest(stored_password.encode(), password.encode())
            if not password_ok:
                return redirect("/?error=invalid")
            # user[3] คือสิทธิ์; lower() ตรงนี้เป็น Python ต่างจาก lower(...) ใน SQL ด้านบน
            role = str(user[3]).strip().lower()
            # not in ตรวจว่าค่าไม่ได้อยู่ในชุดที่อนุญาต
            if role not in ("admin", "owner", "employee", "tenant"):
                return redirect("/?error=role")
            if not is_hash:
                # UPDATE แก้แถวเดิม; SET ระบุค่าที่แก้; WHERE จำกัดเฉพาะบัญชีนี้
                # generate_password_hash สร้างค่าเก็บรหัสผ่านแทนข้อความเดิม
                cursor.execute("""
                    UPDATE public."user" SET password_hash = %s WHERE user_id = %s
                """, (generate_password_hash(password), user[0]))
            # LOCALTIME คือเวลาปัจจุบันของฐานข้อมูล ไม่รวมวันที่ ตามชนิดคอลัมน์ last_login เดิม
            cursor.execute('UPDATE public."user" SET last_login = LOCALTIME WHERE user_id = %s', (user[0],))
            # commit ยืนยันการแก้ข้อมูลในรอบนี้ให้บันทึกจริง
            conn.commit()
            # session ใช้จำผู้ใช้ข้ามหน้า; clear ล้าง Session เดิม ไม่ได้ลบตาราง user
            # Flask เก็บ Session ในคุกกี้ที่ตรวจการแก้ไขได้ แต่ไม่เข้ารหัส จึงไม่เก็บรหัสผ่านไว้ในนี้
            session.clear()
            # ชื่อใน [ ] เราตั้งเอง แต่ทุกไฟล์ที่อ่าน Session ต้องใช้ชื่อให้ตรงกัน
            session["user_id"] = user[0]
            session["username"] = user[1]
            session["role"] = role
            # รหัสสุ่มนี้ให้ JS ส่งกลับตอนแก้ข้อมูล แล้ว common.py ตรวจว่าตรงกับ Session หรือไม่
            session["csrf_token"] = secrets.token_urlsafe(32)
            if role in ("admin", "owner"):
                return redirect("/owner")
            if role == "employee":
                return redirect("/employee")
            return redirect("/tenant")
        # Exception คือข้อผิดพลาด; as error ตั้งชื่อไว้เรียกข้อมูลข้อผิดพลาด
        except Exception as error:
            if conn:
                # rollback ยกเลิกการแก้ข้อมูลที่ยังไม่ได้ commit ในการเชื่อมต่อนี้
                conn.rollback()
            # print แสดงใน Terminal; type(...).__name__ แสดงชื่อชนิดข้อผิดพลาด
            print("Login error:", type(error).__name__)
            return redirect("/?error=database")
        # finally ทำงานแม้มี return ใน try จึงใช้ปิดสิ่งที่เปิดไว้
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    # GET จะมาถึงตรงนี้; render_template อ่าน HTML แล้วส่งกลับไปแสดงในเบราว์เซอร์
    return render_template("login.html")
# เส้นทางเดิมนี้กลับหน้า Login พร้อมล้าง Session ถ้ามีอยู่
@app.route("/login.html")
def login_html():
    session.clear()
    return redirect("/")
# เปิดหน้าสมัครสมาชิกเท่านั้น ยังไม่มี POST สำหรับเพิ่มบัญชี
@app.route("/register.html")
def register():
    return render_template("register.html")
@app.route("/employee")
def employee():
    # การมี user_id ใช้ตรวจว่าผ่าน Login แล้ว แต่ยังต้องตรวจ role แยกด้วย
    if "user_id" not in session:
        return redirect("/")
    if session.get("role") != "employee":
        # != คือไม่เท่ากัน; 403 เป็นรหัสตอบกลับว่าไม่มีสิทธิ์
        return "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", 403
    return "หน้าพนักงาน"
@app.route("/tenant")
def tenant():
    if "user_id" not in session:
        return redirect("/")
    if session.get("role") != "tenant":
        return "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", 403
    return "หน้าผู้เช่า"
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")
# @app.get รับ GET เท่านั้น; เส้นทางนี้ส่งข้อมูล ไม่ใช่หน้า HTML
@app.get("/api/csrf")
def csrf_token():
    if "user_id" not in session:
        # jsonify ส่ง JSON คือข้อมูลแบบชื่อคู่กับค่าให้ JavaScript; 401 หมายถึงต้องเข้าสู่ระบบ
        return jsonify(error="กรุณาเข้าสู่ระบบใหม่"), 401
    if session.get("role") not in ("admin", "owner"):
        return jsonify(error="คุณไม่มีสิทธิ์จัดการข้อมูล"), 403
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return jsonify(token=session["csrf_token"])
# ทำงานเมื่อรันไฟล์นี้โดยตรง ไม่ทำงานเมื่อไฟล์อื่น import เข้ามา
if __name__ == "__main__":
    # 127.0.0.1 เปิดเฉพาะเครื่องนี้; port คือเลขช่องทางเว็บ; debug=False ไม่เปิดหน้าดีบัก
    app.run(host="127.0.0.1", port=5000, debug=False)
