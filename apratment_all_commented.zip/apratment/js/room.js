// room.js — Frontend: room.html → fetch /api/rooms → python/room.py → PostgreSQL
// ไฟล์นี้ใช้ HTML เดิมและข้อมูลจริงจาก API; คอมเมนต์อธิบายโค้ดเดิม ไม่ได้เปลี่ยนรูปแบบการบันทึก
// const เก็บสิ่งที่อ้างถึง; document.getElementById หา id ของชิ้นนั้นใน room.html ถ้าไม่พบจะได้ null
const roomModal = document.getElementById("roomModal");
// roomForm คือฟอร์มเพิ่ม/แก้ไข; roomRows คือ tbody ของตาราง ไม่ใช่ฐานข้อมูลจริง
const roomForm = document.getElementById("roomForm");
const roomRows = document.getElementById("roomRows");
// roomFilter คือฟอร์มค้นหา แยกจาก roomForm ที่บันทึกข้อมูล
const roomFilter = document.getElementById("roomFilter");
const filterMessage = document.getElementById("filterMessage");
const clearFilters = document.getElementById("clearFilters");
// เก็บปุ่มเพิ่ม/แก้ไข/ลบไว้สั่งเปิดปิดและผูกเหตุการณ์ภายหลัง
const addRoom = document.getElementById("addRoom");
const editRoom = document.getElementById("editRoom");
const deleteRoom = document.getElementById("deleteRoom");
// กล่องแจ้งเตือน/หัวข้อ/คำอธิบายฟอร์ม ใช้เปลี่ยนข้อความตามงาน ไม่ต้องแก้ HTML ทุกครั้ง
const roomNotice = document.getElementById("roomNotice");
const roomModalTitle = document.getElementById("roomModalTitle");
const roomFormHelp = document.getElementById("roomFormHelp");
// querySelector เลือกชิ้นแรกที่ตรง CSS selector; ที่นี่ต้องเป็นปุ่ม submit ที่ผูกกับ form="roomForm"
const saveRoom = document.querySelector('[type="submit"][form="roomForm"]');
// let เป็นตัวแปรที่เปลี่ยนค่าภายหลังได้; csrfToken จะรับรหัสจาก /api/csrf ก่อนเขียนข้อมูล
let csrfToken = "";
// [] คือรายการว่าง; เก็บผลจริงจาก API ไม่ใช่ใส่ห้องสมมติ
let roomList = [];
// null คือยังไม่เลือกห้อง; selectedRoom คือห้องในตาราง ส่วน editingRoom คือห้องที่เปิดแก้ในฟอร์ม
let selectedRoom = null;
let editingRoom = null;
// bootstrap.Modal.getOrCreateInstance ใช้หน้าต่างเดิมหรือสร้างตัวควบคุมใหม่ ต้องโหลด Bootstrap JS ก่อน
const modal = bootstrap.Modal.getOrCreateInstance(roomModal);
// removeAttribute เอาคำสั่งเปิด Modal อัตโนมัติออก ให้ openRoomForm เติมข้อมูลก่อนเปิดแทน
addRoom.removeAttribute("data-bs-toggle");
addRoom.removeAttribute("data-bs-target");
// async function มีงานที่รอผลได้; url คือที่อยู่ API; options={} เป็นค่าตั้งต้นแบบชุดข้อมูลว่าง
async function api(url, options = {}) {
    // settings คือ object แบบชื่อ:ค่า สำหรับบอก fetch ว่าจะส่งคำขออย่างไร
    const settings = {
        // credentials:"same-origin" ส่งคุกกี้ Session ให้เว็บต้นทางเดียวกัน เพื่อให้ Python รู้ว่าใครเรียก
        credentials: "same-origin",
        // cache:"no-store" ขอข้อมูลใหม่ ไม่ใช้ผลเก่าของ fetch จากแคชเบราว์เซอร์
        cache: "no-store",
        // ...options กระจายค่าที่ผู้เรียกส่งมาเติม/ทับ settings เช่น method หรือ body
        ...options
    };
    // headers คือข้อมูลกำกับคำขอ; || {} ใช้ชุดว่างเมื่อไม่มี; ... คัดลอกค่ามาเก็บอีกชุด
    settings.headers = {...(options.headers || {})};
    // body ตรงนี้คือข้อมูลที่จะส่ง ไม่ใช่แท็ก <body> ของหน้าเว็บ
    if (settings.body) {
        // Content-Type บอกว่าเนื้อหาที่ส่งเป็น JSON; X-CSRF-Token ส่งรหัสให้ common.py ตรวจ
        settings.headers["Content-Type"] = "application/json";
        settings.headers["X-CSRF-Token"] = csrfToken;
    }
    // fetch ส่งคำขอไป Flask; await รอเฉพาะขั้นตอนนี้ ไม่หยุดหน้าเว็บทั้งหน้า
    const response = await fetch(url, settings);
    // response.json() อ่านผลเป็น object; .catch รับกรณีแปลงไม่ได้; () => ({}) เป็นฟังก์ชันสั้นคืน object ว่าง
    // โค้ดเดิมใช้ {} เมื่อผลไม่ใช่ JSON จึงยังแยกคำตอบผิดรูปแบบได้ไม่ครบ
    const data = await response.json().catch(() => ({}));
    // response.ok จริงเมื่อ HTTP อยู่ช่วง 200–299; ! คือไม่สำเร็จ; fetch ไม่ throw แค่เพราะ HTTP 404/500
    if (!response.ok) {
        // throw new Error ส่งปัญหาให้ catch ของผู้เรียก; ใช้ error จาก Python หรือข้อความสำรอง
        throw new Error(data.error || "ทำรายการไม่สำเร็จ");
    }
    // return คืนผลที่อ่านแล้วให้ loadRooms หรือฟังก์ชันบันทึก ไม่ใช่ return ของ Python
    return data;
}
// ฟังก์ชันแสดงข้อความ; error=false เป็นค่าเริ่มต้น ไม่ใช่ข้อผิดพลาดที่เกิดขึ้นเอง
function showMessage(text, error = false) {
    // textContent ใส่ข้อความธรรมดา ไม่ตีความเป็น HTML
    filterMessage.textContent = text;
    // toggle แบบมีอาร์กิวเมนต์ที่สอง: true บังคับเพิ่ม class, false เอาออก ไม่ใช่สลับทุกครั้ง
    filterMessage.classList.toggle("text-danger", error);
}
// จำห้องที่เลือก แล้วเปิดปุ่มแก้ไข/ลบเฉพาะเมื่อมีรายการ
function setSelected(room) {
    selectedRoom = room;
    // disabled=true ทำให้กดปุ่มไม่ได้; !room เป็นจริงเมื่อ room ยังเป็น null
    editRoom.disabled = !room;
    deleteRoom.disabled = !room;
}
// renderRooms สร้างตารางจาก roomList ไม่ได้บันทึกอะไรลง PostgreSQL
function renderRooms() {
    // replaceChildren() ลบสิ่งที่แสดงใน tbody เก่า ไม่ใช่ DELETE ข้อมูลในฐานข้อมูล
    roomRows.replaceChildren();
    // length นับจำนวนรายการ; === 0 หมายถึงไม่มีแถวให้สร้าง
    if (roomList.length === 0) {
        // insertRow เพิ่ม <tr>; insertCell เพิ่ม <td> ลงหน้าเว็บ
        const row = roomRows.insertRow();
        const cell = row.insertCell();
        // colSpan=7 รวมช่องให้ครอบทั้งเจ็ดคอลัมน์; className กำหนด class ทั้งชุด
        cell.colSpan = 7;
        cell.className = "text-center text-muted py-4";
        cell.textContent = "ไม่พบข้อมูลห้องพัก";
        // return จบเฉพาะฟังก์ชัน renderRooms เมื่อไม่มีรายการ ไม่ปิดโปรแกรม
        return;
    }
    // object นี้แปลรหัสสถานะเป็นข้อความไทย; ไม่ใช่ข้อมูลห้องที่แต่งขึ้น
    const statusText = {
        AVAILABLE: "ว่าง",
        OCCUPIED: "มีผู้เช่า",
        MAINTENANCE: "ปิดปรับปรุง"
    };
    // จับคู่สถานะกับสีป้าย Bootstrap: success เขียว, secondary เทา, warning เหลือง
    const statusClass = {
        AVAILABLE: "text-bg-success",
        OCCUPIED: "text-bg-secondary",
        MAINTENANCE: "text-bg-warning"
    };
    // forEach วนแต่ละห้อง; room => {...} เป็นฟังก์ชันสั้นรับห้องหนึ่งรายการ
    roomList.forEach(room => {
        const row = roomRows.insertRow();
        const selectCell = row.insertCell();
        selectCell.className = "text-center";
        // createElement สร้างชิ้น HTML ยังไม่ขึ้นจอจนกว่าจะนำไปต่อกับกล่อง
        const radio = document.createElement("input");
        // radio เลือกได้ทีละตัวในกลุ่ม name เดียวกัน; form-check-input ตกแต่งปุ่มเลือก
        radio.type = "radio";
        radio.name = "selectedRoom";
        radio.className = "form-check-input";
        // change เกิดเมื่อเลือกเปลี่ยน; () => setSelected(room) จำว่าปุ่มนี้เป็นของห้องไหน
        radio.addEventListener("change", () => setSelected(room));
        // appendChild ใส่ radio ลงช่องตารางที่สร้างไว้
        selectCell.appendChild(radio);
        // room.room_number อ่านช่องข้อมูลที่ Python ส่งมา; จุดนี้ไม่ใช่การเรียกฐานข้อมูลตรงจาก JS
        row.insertCell().textContent = room.room_number;
        row.insertCell().textContent = room.floor;
        row.insertCell().textContent = room.room_type;
        const rentCell = row.insertCell();
        rentCell.className = "text-end";
        // Number แปลงเงินข้อความเป็นเลข; toLocaleString จัดรูปแบบภาษาไทย; สองตัวเลือกบังคับทศนิยมสองตำแหน่ง
        rentCell.textContent = Number(room.monthly_rent).toLocaleString("th-TH", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        const depositCell = row.insertCell();
        depositCell.className = "text-end";
        depositCell.textContent = Number(room.deposit_amount).toLocaleString("th-TH", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        const statusCell = row.insertCell();
        const badge = document.createElement("span");
        // ข้อความครอบด้วย backtick เติมค่า ${...} ได้; [room.status] เลือกสีตามสถานะ; || ใช้สีสำรอง
        badge.className = `badge ${statusClass[room.status] || "text-bg-secondary"}`;
        badge.textContent = statusText[room.status] || room.status;
        statusCell.appendChild(badge);
    });
}
// อ่านข้อมูลใหม่ตามตัวกรอง; message ใช้แสดงผลบันทึกครั้งก่อนพร้อมจำนวนรายการ
async function loadRooms(message = "") {
    // ยกเลิกรายการที่เลือกก่อนโหลด เพื่อไม่ให้ปุ่มแก้ไขยังอ้างห้องเก่า
    setSelected(null);
    showMessage("กำลังโหลดข้อมูลห้องพัก...");
    // URLSearchParams ช่วยสร้างข้อความหลัง ? และแปลงอักขระในคำค้นให้อยู่ใน URL ได้
    const params = new URLSearchParams();
    // .value คือค่าที่กรอก ไม่ใช่ชนิด .type; trim() ตัดช่องว่างหัวท้าย
    const search = document.getElementById("searchRoom").value.trim();
    const floor = document.getElementById("floorFilter").value.trim();
    const status = document.getElementById("statusFilter").value;
    // params.set เพิ่มค่าตามชื่อ; ไม่กรอกจึงไม่ส่งตัวกรองนั้น
    if (search) params.set("q", search);
    if (floor) params.set("floor", floor);
    if (status) params.set("status", status);
    // try/catch จัดการผลผิดพลาดของงาน async เช่นติดต่อเซิร์ฟเวอร์ไม่ได้
    try {
        // toString แปลงตัวกรองเป็นข้อความ; api() คือฟังก์ชันที่ประกาศด้านบน ไม่ใช่คำสั่งสำเร็จรูป
        const data = await api(`/api/rooms?${params.toString()}`);
        // data.items คือชื่อที่ Python ส่ง; || [] ใช้รายการว่างเมื่อไม่มีค่าด้านซ้าย
        roomList = data.items || [];
        renderRooms();
        if (message) {
            showMessage(`${message} พบ ${roomList.length} รายการ`);
        } else {
            showMessage(`พบ ${roomList.length} รายการ`);
        }
    } catch (error) {
        // กรณีผิดพลาดโค้ดเดิมล้างรายการแล้วแสดงข้อความผิดพลาด; คำว่าไม่พบข้อมูลจึงต้องอ่านคู่กับ error ด้านบน
        roomList = [];
        renderRooms();
        showMessage(error.message, true);
    }
}
// room=null หมายถึงโหมดเพิ่ม; ส่งข้อมูลห้องเข้ามาหมายถึงโหมดแก้ไข
function openRoomForm(room = null) {
    // reset คืนค่าฟอร์มเริ่มต้น ไม่ได้ลบห้องจริง
    roomForm.reset();
    // hidden=true ซ่อนกล่องแจ้งเตือน ต่างจาก disabled ที่ปิดการใช้งานช่องกรอก
    roomNotice.hidden = true;
    roomNotice.textContent = "";
    editingRoom = room;
    // เงื่อนไข ? ค่าเมื่อจริง : ค่าเมื่อเท็จ ใช้เปลี่ยนชื่อหัวข้อระหว่างเพิ่มกับแก้ไข
    roomModalTitle.textContent = room ? "แก้ไขห้องพัก" : "เพิ่มห้องพัก";
    roomFormHelp.textContent = "กรอกข้อมูลแล้วกดบันทึกเพื่อบันทึกลงฐานข้อมูล";
    // ตอนแก้ไขเติมทุกช่องจากรายการที่เลือก ไม่ต้องสร้างฟอร์มใหม่
    if (room) {
        document.getElementById("roomId").value = room.room_id;
        document.getElementById("roomNumber").value = room.room_number;
        document.getElementById("roomFloor").value = room.floor;
        document.getElementById("roomType").value = room.room_type;
        document.getElementById("roomStatus").value = room.status;
        document.getElementById("monthlyRent").value = room.monthly_rent;
        document.getElementById("depositAmount").value = room.deposit_amount;
        // description || "" ใช้ข้อความว่างเมื่อไม่มีรายละเอียด
        document.getElementById("roomDescription").value = room.description || "";
    }
    // show() เปิดหน้าต่าง Bootstrap หลังตั้งค่าฟอร์มแล้ว
    modal.show();
}
// ผูกเหตุการณ์ click ของปุ่มเพิ่ม ไม่เรียก openRoomForm ทันทีตอนโหลดไฟล์
addRoom.addEventListener("click", () => openRoomForm());
editRoom.addEventListener("click", function () {
    if (selectedRoom) {
        openRoomForm(selectedRoom);
    }
});
// ฟังก์ชันเหตุการณ์ลบเป็น async เพราะต้องรอคำตอบจาก Backend
deleteRoom.addEventListener("click", async function () {
    // ยังไม่เลือกห้องก็หยุด ไม่เรียก API ด้วยรหัสว่าง
    if (!selectedRoom) return;
    // confirm ถามยืนยัน; คืน false เมื่อยกเลิก; ข้อความนี้ไม่ใช่การตรวจสิทธิ์แทน Python
    if (!confirm(`ยืนยันลบห้อง ${selectedRoom.room_number}?`)) {
        return;
    }
    try {
        // รหัสห้องอยู่ท้าย URL ให้ route <int:room_id> รับ; method DELETE ขอให้ Backend ลบ
        const data = await api(`/api/rooms/${selectedRoom.room_id}`, {
            method: "DELETE",
            // JSON.stringify({}) ทำชุดว่างเป็นข้อความ JSON; ทำให้ api() แนบ Content-Type และ CSRF ด้วย
            body: JSON.stringify({})
        });
        // ลบสำเร็จแล้วอ่านตารางใหม่ ไม่เพียงลบแถวบนจอ
        await loadRooms(data.message);
    } catch (error) {
        showMessage(error.message, true);
    }
});
// submit จับทั้งการคลิกบันทึกและ Enter ในฟอร์ม
roomForm.addEventListener("submit", async function (event) {
    // preventDefault หยุดการส่งฟอร์มปกติ แล้วใช้ fetch ส่งเอง ไม่ได้ยกเลิกการบันทึกทั้งหมด
    event.preventDefault();
    // reportValidity ตรวจ required/min/max/step ของ HTML ก่อน แต่ Backend ยังต้องตรวจซ้ำ
    if (!roomForm.reportValidity()) {
        return;
    }
    // FormData อ่านช่องที่มี name และไม่ disabled; Object.fromEntries แปลงคู่ชื่อ/ค่าเป็น object
    const body = Object.fromEntries(new FormData(roomForm));
    roomNotice.hidden = true;
    // ปิดปุ่มบันทึกระหว่างรอผล ลดการคลิกซ้ำ
    saveRoom.disabled = true;
    try {
        // มี editingRoom ส่ง PUT ไปห้องนั้น; ไม่มีส่ง POST ไป /api/rooms เพื่อเพิ่มห้อง
        const data = await api(
            editingRoom ? `/api/rooms/${editingRoom.room_id}` : "/api/rooms",
            {
                method: editingRoom ? "PUT" : "POST",
                body: JSON.stringify(body)
            }
        );
        // hide() ปิด Modal เมื่อบันทึกสำเร็จ; loadRooms ขอข้อมูลล่าสุดมาสร้างตารางใหม่
        modal.hide();
        await loadRooms(data.message);
    // catch แสดงปัญหาไว้ในฟอร์มโดยไม่ปิดฟอร์ม ให้ผู้ใช้เห็นสิ่งที่ต้องแก้
    } catch (error) {
        roomNotice.className = "alert alert-danger mt-3 mb-0";
        roomNotice.textContent = error.message;
        roomNotice.hidden = false;
    // finally ทำทั้งสำเร็จและล้มเหลว จึงเปิดปุ่มบันทึกกลับเสมอ
    } finally {
        saveRoom.disabled = false;
    }
});
// ฟอร์มนี้เป็นตัวกรอง ใช้ GET ผ่าน loadRooms ไม่ใช่ POST เพิ่มห้อง
roomFilter.addEventListener("submit", function (event) {
    event.preventDefault();
    loadRooms();
});
// ล้างเฉพาะช่องค้นหาแล้วอ่านรายการใหม่ ไม่ใช่ล้างตารางในฐานข้อมูล
clearFilters.addEventListener("click", function () {
    roomFilter.reset();
    loadRooms();
});
// ขั้นตอนเริ่มหน้า: ขอ CSRF สำหรับการแก้ข้อมูล แล้วจึงอ่านรายการห้อง
async function start() {
    try {
        const data = await api("/api/csrf");
        csrfToken = data.token;
        await loadRooms();
    } catch (error) {
        showMessage(error.message, true);
    }
}
// เรียก start() จริงหนึ่งครั้งเมื่อโหลดไฟล์ หลังประกาศฟังก์ชันทั้งหมดแล้ว
start();
