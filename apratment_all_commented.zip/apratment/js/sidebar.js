// sidebar.js — ใช้ร่วมกันทุกหน้าที่มีปุ่มสามขีด; ไม่ได้อ่านฐานข้อมูล
// const เก็บสิ่งที่อ้างถึงแล้วไม่เปลี่ยนไปอ้างตัวใหม่; document คือหน้าเว็บ; getElementById หา id ที่ตรงกัน
const sidebarToggle = document.getElementById("sidebarToggle");
// sidebarToggle คือปุ่ม ส่วน sidebarMenu คือกล่องเมนู ต้องตรง id ใน HTML ไม่ใช่ชื่อ class
const sidebarMenu = document.getElementById("sidebarMenu");
// && ต้องพบทั้งสองชิ้นก่อน; หาไม่พบจะได้ null จึงข้ามส่วนนี้
if (sidebarToggle && sidebarMenu) {
    // addEventListener รอ click แล้วเรียก function; ปุ่มธรรมดาไม่ส่งฟอร์ม
    sidebarToggle.addEventListener("click", function () {
        // classList.toggle สลับเพิ่ม/ลบ class active และคืน true เมื่อหลังสลับมี class นี้
        // active ของ sidebar ใช้เปิดเมนู ต่างจาก active ของ menu-link ที่เน้นหน้าปัจจุบัน
        const isOpen = sidebarMenu.classList.toggle("active");
        // inert ปิดการคลิก/เลือกด้วย Tab ภายในเมนู; ! กลับ true/false จึงปิดการเลือกเฉพาะตอนเมนูซ่อน
        sidebarMenu.inert = !isOpen;
        // setAttribute แก้ข้อมูลกำกับ HTML; String แปลงเป็นข้อความ; aria-expanded บอกสถานะ ไม่ได้เลื่อนเมนูเอง
        sidebarToggle.setAttribute("aria-expanded", String(isOpen));
    });
    // keydown คือกดแป้น; event เก็บข้อมูลเหตุการณ์; ฟังที่ document จึงรับได้จากหลายตำแหน่งในหน้า
    document.addEventListener("keydown", function (event) {
        // event.key คือแป้นที่กด; === เทียบค่าและชนิด; contains ตรวจ class โดยไม่แก้ไข
        if (event.key === "Escape" && sidebarMenu.classList.contains("active")) {
            // focus() ย้ายจุดเลือกกลับปุ่มเมนู ต่างจาก :focus ใน CSS ที่ใช้ตกแต่ง
            sidebarToggle.focus();
            // remove เอา active ออกเสมอ ไม่ใช่ toggle เพราะกด Escape ต้องปิดอย่างเดียว
            sidebarMenu.classList.remove("active");
            sidebarMenu.inert = true;
            sidebarToggle.setAttribute("aria-expanded", "false");
        }
    });
}
