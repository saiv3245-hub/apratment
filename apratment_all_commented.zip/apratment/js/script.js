// const ตั้งชื่อตัวแปรที่ห้ามเปลี่ยนไปอ้างค่าอื่น แต่ยังแก้ข้อมูลของสิ่งที่อ้างถึงได้
// document คือหน้าเว็บ; getElementById หาแต่ละชิ้นจาก id ถ้าไม่พบจะได้ null
const togglePassword = document.getElementById("togglePassword");
const password = document.getElementById("password");
const passwordIcon = document.getElementById("passwordIcon");
const loginMessage = document.getElementById("loginMessage");
// if ตรวจเงื่อนไข; && ต้องมีครบทุกตัว จึงไม่พังเมื่อเปิดหน้าที่ไม่มีปุ่มนี้
if (togglePassword && password && passwordIcon) {
    // addEventListener กำหนดสิ่งที่จะทำเมื่อเกิด click; function คือชุดคำสั่งที่รอให้เรียก
    togglePassword.addEventListener("click", function () {
        // === ตรวจว่าค่าและชนิดตรงกัน; .type คือชนิดช่องกรอก ไม่ใช่ค่าที่ผู้ใช้พิมพ์
        if (password.type === "password") {
            // = กำหนดค่า; เปลี่ยนเป็น text เพื่อให้เห็นรหัส ไม่ได้เปลี่ยนรหัสจริง
            password.type = "text";
            // classList คือรายการ class; remove เอาออก; add เพิ่มเข้าไป
            passwordIcon.classList.remove("bi-eye");
            passwordIcon.classList.add("bi-eye-slash");
        } else {
            // else ทำเมื่อเงื่อนไขด้านบนไม่จริง จึงซ่อนรหัสกลับ
            password.type = "password";
            passwordIcon.classList.remove("bi-eye-slash");
            passwordIcon.classList.add("bi-eye");
        }
    });
}
// ปุ่มนี้อยู่หน้า Register ต่างจาก togglePassword ที่อยู่หน้า Login
// ทั้งสองหน้าใช้ id="password" ได้ เพราะเป็นคนละเอกสาร ไม่ใช่ id ซ้ำในหน้าเดียว
const toggleRegisterPassword = document.getElementById("toggleRegisterPassword");
const registerPasswordIcon = document.getElementById("registerPasswordIcon");
if (toggleRegisterPassword && password && registerPasswordIcon) {
    toggleRegisterPassword.addEventListener("click", function () {
        if (password.type === "password") {
            password.type = "text";
            registerPasswordIcon.classList.remove("bi-eye");
            registerPasswordIcon.classList.add("bi-eye-slash");
        } else {
            password.type = "password";
            registerPasswordIcon.classList.remove("bi-eye-slash");
            registerPasswordIcon.classList.add("bi-eye");
        }
    });
}
// ชุดนี้ควบคุมช่องยืนยันรหัสผ่าน ไม่ใช่ช่องรหัสผ่านหลัก
const confirmPassword = document.getElementById("confirmPassword");
const toggleConfirmPassword = document.getElementById("toggleConfirmPassword");
const confirmPasswordIcon = document.getElementById("confirmPasswordIcon");
if (toggleConfirmPassword && confirmPassword && confirmPasswordIcon) {
    toggleConfirmPassword.addEventListener("click", function () {
        if (confirmPassword.type === "password") {
            confirmPassword.type = "text";
            confirmPasswordIcon.classList.remove("bi-eye");
            confirmPasswordIcon.classList.add("bi-eye-slash");
        } else {
            confirmPassword.type = "password";
            confirmPasswordIcon.classList.remove("bi-eye-slash");
            confirmPasswordIcon.classList.add("bi-eye");
        }
    });
}
const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");
if (registerForm && password && confirmPassword && registerMessage) {
    // submit เกิดตอนส่งฟอร์ม ทั้งกดปุ่มหรือ Enter; event คือข้อมูลเหตุการณ์ที่เกิด
    registerForm.addEventListener("submit", function (event) {
        // หยุดการส่งจริงทุกครั้ง เพราะ Backend สมัครสมาชิกยังไม่ได้ทำ
        // ไม่ใช้คำสั่งนี้กับ Login ซึ่งต้องส่ง POST ไปให้ Python ตรวจบัญชี
        event.preventDefault();
        registerMessage.classList.add("d-none");
        // reportValidity ตรวจ required, type, pattern แล้วแสดงช่องที่กรอกไม่ผ่าน
        // ! กลับเงื่อนไข; return หยุดเฉพาะฟังก์ชันนี้ ไม่ใช่ปิดทั้งเว็บ
        if (!registerForm.reportValidity()) return;
        // .value คือข้อความที่กรอก; !== คือค่าหรือชนิดไม่ตรงกัน
        if (password.value !== confirmPassword.value) {
            // textContent ใส่ข้อความธรรมดา ไม่ตีความเป็นแท็ก HTML
            registerMessage.textContent = "รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน";
            // className กำหนด class ทั้งชุด ต่างจาก classList.add ที่เพิ่มเพียงหนึ่ง class
            registerMessage.className = "alert alert-danger mt-3";
            // focus ย้ายจุดกรอกไปที่ช่องยืนยันรหัสผ่าน
            confirmPassword.focus();
            return;
        }
        registerMessage.textContent = "รูปแบบข้อมูลผ่านแล้ว แต่ยังไม่ได้สร้างบัญชี เพราะยังไม่มีระบบบันทึกสมัครสมาชิก";
        registerMessage.className = "alert alert-info mt-3";
    });
}
// window.location.search คือข้อความหลัง ? เช่น ?error=invalid
// new URLSearchParams สร้างตัวอ่านค่าจากข้อความนั้น ไม่ได้เรียกฐานข้อมูล
const params = new URLSearchParams(window.location.search);
const error = params.get("error");
if (loginMessage && error) {
    if (error === "invalid") {
        loginMessage.textContent = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
    } else if (error === "inactive") {
        loginMessage.textContent = "บัญชีผู้ใช้นี้ถูกปิดใช้งาน";
    } else if (error === "role") {
        loginMessage.textContent = "ไม่พบสิทธิ์การใช้งานของผู้ใช้";
    } else if (error === "database") {
        loginMessage.textContent = "เกิดข้อผิดพลาดระหว่างตรวจบัญชี กรุณาดู Terminal ของ Python";
    } else {
        loginMessage.textContent = "ไม่สามารถเข้าสู่ระบบได้ กรุณาลองใหม่";
    }
    // d-none เป็น Bootstrap ที่ซ่อนกล่อง เอาออกเพื่อให้ข้อความปรากฏ
    loginMessage.classList.remove("d-none");
}
