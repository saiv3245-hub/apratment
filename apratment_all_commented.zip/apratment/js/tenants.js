// tenants.js — Frontend หน้า tenants.html; ส่งคำขอให้ python/tenant.py ผ่าน fetch
// ชื่อผู้เช่าในตารางอ่านจาก API; ไฟล์นี้ไม่เชื่อม PostgreSQL ด้วยรหัสผ่านเอง
// const เก็บสิ่งที่อ้างถึง; document.getElementById หาแต่ละชิ้นจาก id ใน tenants.html
const tenantModal = document.getElementById("tenantModal");
// tenantForm ใช้เพิ่ม/แก้ไขคน; tenantRows คือ tbody ที่จะแสดงผล ไม่ใช่ตารางฐานข้อมูล
const tenantForm = document.getElementById("tenantForm");
const tenantRows = document.getElementById("tenantRows");
// tenantFilter เป็นฟอร์มค้นหาคน แยกจาก tenantForm ที่บันทึกข้อมูล
const tenantFilter = document.getElementById("tenantFilter");
const tenantFilterMessage = document.getElementById("tenantFilterMessage");
const clearTenantFilters = document.getElementById("clearTenantFilters");
// ปุ่มเพิ่ม ดู แก้ไข ลบ ทำหน้าที่ต่างกัน แม้ใช้หน้าต่างรายละเอียดใบเดียวกัน
const addTenant = document.getElementById("addTenant");
const viewTenant = document.getElementById("viewTenant");
const editTenant = document.getElementById("editTenant");
const deleteTenant = document.getElementById("deleteTenant");
const tenantNotice = document.getElementById("tenantNotice");
// tenantUser คือ select ของบัญชี user_id ไม่ใช่บัญชีเจ้าของหอที่กำลัง Login
const tenantUser = document.getElementById("tenantUser");
const tenantModalTitle = document.getElementById("tenantModalTitle");
const tenantFormHelp = document.getElementById("tenantFormHelp");
// querySelector เลือกปุ่มที่ตรงทั้ง type="submit" และ form="tenantForm" แม้ปุ่มอยู่นอก form
const saveTenant = document.querySelector('[type="submit"][form="tenantForm"]');
// let เปลี่ยนค่าได้; csrfToken จะรับรหัสจาก /api/csrf; [] คือรายการผู้เช่าที่ยังว่าง
let csrfToken = "";
let tenantList = [];
// null คือยังไม่มีรายการ; selectedTenant เป็นคนที่เลือกในตาราง ส่วน editingTenant เป็นข้อมูลในฟอร์ม
let selectedTenant = null;
let editingTenant = null;
// false คือค่าเท็จ; viewingTenant ใช้บอกว่าเปิดเพื่อดูอย่างเดียวหรือไม่
let viewingTenant = false;
// getOrCreateInstance ใช้/สร้างตัวควบคุม Modal เดิม; ต้องโหลด bootstrap.bundle.min.js ก่อน
const modal = bootstrap.Modal.getOrCreateInstance(tenantModal);
// เอาการเปิด Modal อัตโนมัติออก เพื่อให้โหลดบัญชี/รายละเอียดให้เสร็จก่อนเปิดเอง
addTenant.removeAttribute("data-bs-toggle");
addTenant.removeAttribute("data-bs-target");
// async function รองรับ await; api เป็นชื่อฟังก์ชันของเรา; options={} คือค่าเริ่มต้น
async function api(url, options = {}) {
    // object ใช้ชื่อ:ค่าเพื่อกำหนดคำขอ; credentials ส่ง Session ให้ต้นทางเดียวกัน; cache ไม่ใช้ผลเก่า
    const settings = {
        credentials: "same-origin",
        cache: "no-store",
        // ...options กระจายค่ามารวม ผู้เรียกจึงเลือก method กับ body ได้
        ...options
    };
    // headers เป็นข้อมูลกำกับ; || {} ใช้ชุดว่างเมื่อไม่มี; ... คัดลอกข้อมูล ไม่ใช่รับ SQL
    settings.headers = {...(options.headers || {})};
    // body คือเนื้อหาที่ส่งไปเซิร์ฟเวอร์ ไม่ใช่แท็ก body ของ HTML
    if (settings.body) {
        // บอกชนิด JSON และแนบรหัส CSRF ให้ common.py ตรวจการเพิ่ม/แก้ไข/ลบ
        settings.headers["Content-Type"] = "application/json";
        settings.headers["X-CSRF-Token"] = csrfToken;
    }
    // fetch ส่งคำขอ; await รอผลในฟังก์ชันนี้ แต่หน้าเว็บยังตอบสนองอย่างอื่นได้
    const response = await fetch(url, settings);
    // json() อ่านคำตอบเป็น object; catch คืน {} ถ้าแปลงไม่ได้; () => ({}) เป็นฟังก์ชันสั้นที่คืน object
    // ข้อสังเกต: โค้ดเดิมยังอาจมองคำตอบผิดรูปแบบเป็นชุดว่าง จึงต้องดู HTTP status และข้อความประกอบ
    const data = await response.json().catch(() => ({}));
    // ok จริงเมื่อสถานะ HTTP เป็น 200–299; ! คือไม่สำเร็จ
    if (!response.ok) {
        // throw ส่ง Error ไปให้ catch ของฟังก์ชันที่เรียก; || เลือกข้อความสำรองเมื่อไม่มี error
        throw new Error(data.error || "ทำรายการไม่สำเร็จ");
    }
    return data;
}
// แสดงข้อความเหนือรายการ; error=false คือสถานะปกติ ไม่ใช่ exception
function showMessage(text, error = false) {
    // textContent ใส่ข้อความ ไม่แปลเป็นแท็ก HTML
    tenantFilterMessage.textContent = text;
    // toggle(class, true/false) บังคับเพิ่ม/เอาสีแดงออก ไม่ใช่สลับทุกครั้งแบบมีพารามิเตอร์เดียว
    tenantFilterMessage.classList.toggle("text-danger", error);
}
// จำคนที่เลือก แล้วปรับว่าปุ่มดู/แก้ไข/ลบกดได้หรือไม่
function setSelected(tenant) {
    selectedTenant = tenant;
    // disabled ปิดการกดปุ่ม; !tenant จริงเมื่อไม่มีคนที่เลือก
    viewTenant.disabled = !tenant;
    editTenant.disabled = !tenant;
    deleteTenant.disabled = !tenant;
}
// สร้างแถวตารางบนเว็บจากข้อมูลที่ API ส่งมา ไม่เพิ่มข้อมูลในฐานข้อมูล
function renderTenants() {
    // replaceChildren ล้างแถวบนจอเดิม ต่างจาก API DELETE ที่ลบข้อมูลจริง
    tenantRows.replaceChildren();
    // length นับรายการ; === เทียบค่าและชนิด; ว่างก็สร้างหนึ่งแถวข้อความแทน
    if (tenantList.length === 0) {
        // insertRow เพิ่ม tr; insertCell เพิ่ม td; colSpan=6 รวมช่องให้ครบหกคอลัมน์
        const row = tenantRows.insertRow();
        const cell = row.insertCell();
        cell.colSpan = 6;
        cell.className = "text-center text-muted py-4";
        cell.textContent = "ไม่พบข้อมูลผู้เช่า";
        return;
    }
    // forEach วนคนละรอบ; tenant => {...} คือฟังก์ชันสั้นรับผู้เช่าหนึ่งคน
    tenantList.forEach(tenant => {
        const row = tenantRows.insertRow();
        const selectCell = row.insertCell();
        selectCell.className = "text-center";
        // createElement สร้าง input; type=radio เลือกได้หนึ่งตัวในกลุ่ม name เดียวกัน
        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "selectedTenant";
        radio.className = "form-check-input";
        // change เกิดเมื่อเปลี่ยนการเลือก; appendChild นำปุ่มเลือกไปใส่บนจอจริง
        radio.addEventListener("change", () => setSelected(tenant));
        selectCell.appendChild(radio);
        // จุดหลัง tenant ใช้อ่านชื่อช่องจาก JSON; ไม่ใช่การเรียกฐานข้อมูลโดยตรง
        row.insertCell().textContent = tenant.tenant_code;
        // backtick ทำข้อความที่เติม ${...} ได้; รวมชื่อกับนามสกุลเพื่อแสดงเท่านั้น
        row.insertCell().textContent = `${tenant.first_name} ${tenant.last_name}`;
        row.insertCell().textContent = tenant.phone;
        row.insertCell().textContent = tenant.email;
        const statusCell = row.insertCell();
        const badge = document.createElement("span");
        // เงื่อนไข ? ค่าเมื่อจริง : ค่าเมื่อเท็จ ใช้เลือกสีสถานะ; className กำหนด class ทั้งชุด
        badge.className = tenant.is_active ? "badge text-bg-success" : "badge text-bg-secondary";
        // is_active ตรงนี้คือสถานะข้อมูลผู้เช่า ไม่ได้หมายถึงสิทธิ์ Login ของตาราง user
        badge.textContent = tenant.is_active ? "เปิดใช้งาน" : "ปิดใช้งาน";
        statusCell.appendChild(badge);
    });
}
// โหลดผู้เช่าตามตัวกรอง; message ใช้แนบข้อความหลังบันทึก/ลบสำเร็จ
async function loadTenants(message = "") {
    // ยกเลิกคนที่เลือกก่อนอ่านรายการใหม่ ไม่ปล่อยปุ่มแก้อ้างข้อมูลเก่า
    setSelected(null);
    showMessage("กำลังโหลดข้อมูลผู้เช่า...");
    // URLSearchParams สร้างค่าหลัง ? ให้ถูกการเข้ารหัส URL
    const params = new URLSearchParams();
    // .value คือข้อความในช่อง; trim ตัดช่องว่างหัวท้าย
    const search = document.getElementById("searchTenant").value.trim();
    const status = document.getElementById("tenantStatusFilter").value;
    // set เพิ่มตัวกรองที่กรอกมา; ช่องว่างคือไม่จำกัดเงื่อนไขนั้น
    if (search) params.set("q", search);
    if (status) params.set("status", status);
    // try/catch รับข้อผิดพลาดจากงานที่รอผล
    try {
        // toString แปลงตัวกรองเป็นข้อความสำหรับ URL; await รอข้อมูลก่อนสร้างตาราง
        const data = await api(`/api/tenants?${params.toString()}`);
        // data.items คือชุดรายการที่ Backend ส่ง; || [] เป็นค่าเริ่มต้นเมื่อไม่มีรายการในคำตอบ
        tenantList = data.items || [];
        renderTenants();
        if (message) {
            showMessage(`${message} พบ ${tenantList.length} รายการ`);
        } else {
            showMessage(`พบ ${tenantList.length} รายการ`);
        }
    } catch (error) {
        // ข้อผิดพลาดจะล้างตารางเป็นว่างและแสดงข้อความ error ด้านบน จึงไม่ควรดูแค่ข้อความไม่พบข้อมูล
        tenantList = [];
        renderTenants();
        showMessage(error.message, true);
    }
}
// อ่านบัญชีสำหรับช่อง select; 0 คือไม่มีผู้เช่าปัจจุบัน ส่วน currentUserId ใช้เลือกบัญชีเดิมตอนแก้
async function loadTenantUsers(currentTenantId = 0, currentUserId = "") {
    // เปิด select ก่อนเติมตัวเลือก แล้วล้าง option เก่าออก
    tenantUser.disabled = false;
    tenantUser.replaceChildren();
    // option ตัวแรกเป็นข้อความชวนเลือก value ว่าง ไม่ใช่บัญชีจริง
    const first = document.createElement("option");
    first.value = "";
    first.textContent = "เลือกบัญชีผู้ใช้งาน";
    tenantUser.appendChild(first);
    // ส่ง tenant_id ไป Backend; โค้ดเดิมส่ง 0 ตอนเพิ่ม ซึ่งต้องให้ตัวตรวจฝั่ง Python รองรับด้วย
    const data = await api(`/api/tenant-users?tenant_id=${currentTenantId}`);
    // วนบัญชีจริงแล้วสร้าง option; value เก็บ user_id แต่ textContent แสดง user_name
    data.items.forEach(user => {
        const option = document.createElement("option");
        option.value = user.user_id;
        option.textContent = user.user_name;
        tenantUser.appendChild(option);
    });
    if (currentUserId) {
        // String เปลี่ยนเลขเป็นข้อความให้ตรงกับค่า option ที่ HTML เก็บ
        tenantUser.value = String(currentUserId);
    }
    // เหลือหนึ่ง option หมายถึงมีแต่ตัวชวนเลือก ไม่มีบัญชีให้ผูก จึงปิดช่องและแจ้งผู้ใช้
    if (tenantUser.options.length === 1) {
        tenantUser.disabled = true;
        first.textContent = "ไม่มีบัญชีผู้เช่าที่ยังไม่ได้เชื่อมข้อมูล";
    }
}
// setFormDisabled ใช้เปิดหรือปิดช่องทั้งหมดสำหรับโหมดดูข้อมูล
function setFormDisabled(disabled) {
    // querySelectorAll ได้ทุกชิ้นที่ตรง; จุลภาคแยกแท็กหลายชนิด; forEach ทำทีละช่อง
    tenantForm.querySelectorAll("input, select, textarea").forEach(field => {
        // !== คือไม่เท่ากัน; type=hidden ไม่ใช่ช่องที่ให้แก้บนหน้าจอ จึงไม่รวมตอนปิดช่อง
        if (field.type !== "hidden") {
            field.disabled = disabled;
        }
    });
}
// mode เป็นข้อความ add/view/edit ที่ปุ่มส่งมา ไม่ใช่ชื่อเส้นทาง API
async function openTenantForm(mode) {
    // โหมดดู/แก้ต้องมี selectedTenant; && ต้องจริงทั้งสองฝั่งจึง return
    if (mode !== "add" && !selectedTenant) {
        return;
    }
    // reset คืนค่าเริ่มต้นของฟอร์ม ไม่ลบข้อมูลผู้เช่า; hidden ซ่อนข้อความแจ้งเตือน
    tenantForm.reset();
    tenantNotice.hidden = true;
    tenantNotice.textContent = "";
    editingTenant = null;
    // mode === "view" ได้ true/false เก็บไว้เพื่อปิดช่องกรอกและซ่อนบันทึก
    viewingTenant = mode === "view";
    try {
        // โหมดเพิ่มเริ่มฟอร์มว่างและขอรายชื่อบัญชีที่ยังไม่ได้ผูก
        if (mode === "add") {
            tenantModalTitle.textContent = "เพิ่มผู้เช่า";
            tenantFormHelp.textContent = "เลือกบัญชีผู้ใช้งาน แล้วกรอกข้อมูลผู้เช่า";
            setFormDisabled(false);
            await loadTenantUsers();
            saveTenant.hidden = false;
        // โหมดดู/แก้ ขอข้อมูลคนเดียวจาก API รายละเอียด ไม่ใช้เพียงข้อมูลสั้นในตาราง
        } else {
            const data = await api(`/api/tenants/${selectedTenant.tenant_id}`);
            // data.item เป็นคนเดียว ต่างจาก data.items ที่เป็นรายการหลายคน
            editingTenant = data.item;
            tenantModalTitle.textContent = viewingTenant ? "ข้อมูลผู้เช่า" : "แก้ไขผู้เช่า";
            tenantFormHelp.textContent = viewingTenant
                ? "รายละเอียดข้อมูลผู้เช่า"
                : "แก้ไขข้อมูลแล้วกดบันทึก";
            setFormDisabled(false);
            // โหลดบัญชีเดิมกลับเข้าช่องเลือกด้วย ไม่ให้ข้อมูลหายเพราะบัญชีถูกผูกไปแล้ว
            await loadTenantUsers(editingTenant.tenant_id, editingTenant.user_id);
            // Object.entries แปลง object เป็นคู่ชื่อ/ค่า; ([key, value]) แยกค่าของแต่ละคู่
            Object.entries(editingTenant).forEach(([key, value]) => {
                // form.elements.namedItem หาช่องด้วย name หรือ id; key จึงต้องตรงกับชื่อช่อง HTML
                const field = tenantForm.elements.namedItem(key);
                if (field) {
                    // value == null ใช้จับทั้ง null และ undefined; String(value) ทำค่าอื่นเป็นข้อความให้ช่องกรอก
                    field.value = value == null ? "" : String(value);
                }
            });
            // boolean จริง/เท็จจาก JSON ต้องแปลงเป็น "true"/"false" ให้ตรง value ของ option
            document.getElementById("tenantStatus").value = editingTenant.is_active ? "true" : "false";
            // โหมดดูปิดทุกช่องและซ่อนปุ่มบันทึก; เป็นการคุมหน้าเว็บ ไม่ใช่การตรวจสิทธิ์แทน Backend
            if (viewingTenant) {
                setFormDisabled(true);
                saveTenant.hidden = true;
            } else {
                saveTenant.hidden = false;
            }
        }
        // modal.show เปิดหลังอ่านรายละเอียดและบัญชีสำเร็จแล้ว
        modal.show();
    } catch (error) {
        showMessage(error.message, true);
    }
}
// ผูกปุ่มกับแต่ละโหมดด้วยฟังก์ชันสั้น ไม่เปิดทุกฟอร์มทันทีตอนโหลดไฟล์
addTenant.addEventListener("click", () => openTenantForm("add"));
viewTenant.addEventListener("click", () => openTenantForm("view"));
editTenant.addEventListener("click", () => openTenantForm("edit"));
// เหตุการณ์ลบเป็น async เพราะรอผลจาก Python
deleteTenant.addEventListener("click", async function () {
    if (!selectedTenant) return;
    // confirm ถามยืนยันก่อนส่ง DELETE; ยกเลิกแล้ว return
    if (!confirm(`ยืนยันลบผู้เช่า ${selectedTenant.tenant_code}?`)) {
        return;
    }
    try {
        // รหัสท้าย URL ระบุคนที่จะลบ; method DELETE เลือกเส้นทางลบของ Backend
        const data = await api(`/api/tenants/${selectedTenant.tenant_id}`, {
            method: "DELETE",
            // JSON.stringify({}) ส่ง object ว่างเป็น JSON พร้อมทำให้ api แนบ CSRF
            body: JSON.stringify({})
        });
        // ลบสำเร็จจึงโหลดรายการจากฐานข้อมูลอีกครั้ง
        await loadTenants(data.message);
    } catch (error) {
        showMessage(error.message, true);
    }
});
// submit ทำเมื่อคลิกบันทึกหรือ Enter ไม่ใช่แค่ event click ของปุ่ม
tenantForm.addEventListener("submit", async function (event) {
    // preventDefault ไม่ส่งฟอร์มแบบหน้าเปลี่ยน แล้วใช้ fetch ส่งข้อมูลแทน
    event.preventDefault();
    // reportValidity ตรวจ required/email ฯลฯ ใน HTML; ยังต้องตรวจ Backend อีกชั้น
    if (!tenantForm.reportValidity()) {
        return;
    }
    // disabled หรือ value ว่างแปลว่ายังไม่มีบัญชีให้ผูก ต้องหยุดก่อนส่งข้อมูล
    if (tenantUser.disabled || !tenantUser.value) {
        tenantNotice.className = "alert alert-danger mt-3 mb-0";
        tenantNotice.textContent = "กรุณาเลือกบัญชีผู้ใช้งานสำหรับผู้เช่า";
        tenantNotice.hidden = false;
        return;
    }
    // FormData อ่านช่องที่มี name และไม่ disabled; Object.fromEntries ทำเป็น object ชื่อคู่กับค่า
    const body = Object.fromEntries(new FormData(tenantForm));
    // ระบุ user_id จากช่องเลือกให้ชัด ก่อน JSON.stringify ส่งไป Python
    body.user_id = tenantUser.value;
    tenantNotice.hidden = true;
    // ปิดปุ่มระหว่างส่ง ลดการคลิกซ้ำ ไม่ใช่การปิดบัญชีผู้ใช้
    saveTenant.disabled = true;
    try {
        // มี editingTenant ส่ง PUT พร้อมรหัสเดิม; ไม่มีส่ง POST สร้างผู้เช่ารายใหม่
        const data = await api(
            editingTenant ? `/api/tenants/${editingTenant.tenant_id}` : "/api/tenants",
            {
                method: editingTenant ? "PUT" : "POST",
                body: JSON.stringify(body)
            }
        );
        // hide ปิดฟอร์มหลังสำเร็จ; loadTenants อ่านรายการจริงกลับมาแสดงใหม่
        modal.hide();
        await loadTenants(data.message);
    // ไม่สำเร็จให้เปิดฟอร์มค้างและแสดงข้อความจาก Backend
    } catch (error) {
        tenantNotice.className = "alert alert-danger mt-3 mb-0";
        tenantNotice.textContent = error.message;
        tenantNotice.hidden = false;
    // finally เปิดปุ่มบันทึกกลับทั้งกรณีสำเร็จและผิดพลาด
    } finally {
        saveTenant.disabled = false;
    }
});
// ฟอร์มตัวกรองหยุดการส่งปกติแล้วเรียก GET ค้นหา ไม่บันทึกผู้เช่า
tenantFilter.addEventListener("submit", function (event) {
    event.preventDefault();
    loadTenants();
});
// reset เฉพาะตัวกรอง แล้วโหลดข้อมูล ไม่ลบตารางจริง
clearTenantFilters.addEventListener("click", function () {
    tenantFilter.reset();
    loadTenants();
});
// เริ่มโดยขอรหัส CSRF ของ Session ก่อน เพื่อใช้ตอนบันทึกหรือลบ
async function start() {
    try {
        const data = await api("/api/csrf");
        csrfToken = data.token;
        await loadTenants();
    } catch (error) {
        showMessage(error.message, true);
    }
}
// เรียกฟังก์ชันเริ่มหน้า หลังประกาศทุกฟังก์ชันไว้แล้ว
start();
