// owner.js — อ่านข้อมูล Dashboard จริงจาก python/owner.py แล้วเติมตัวเลข ตารางบิล และงานซ่อม
// (() => {...})(); สร้างฟังก์ชันแล้วเรียกทันที เพื่อไม่ให้ชื่อตัวแปรภายในชนกับสคริปต์อื่น
(() => {
    // const เก็บชิ้นที่อ้างถึง; getElementById หาแต่ละจุดแสดงผลจาก id ใน owner.html
    const totalRooms = document.getElementById("totalRooms");
    const availableRooms = document.getElementById("availableRooms");
    const activeTenants = document.getElementById("activeTenants");
    const overdueBills = document.getElementById("overdueBills");
    // invoiceRows คือ tbody ตารางบิล; repairList คือกล่องรายการซ่อม; dashboardMessage คือข้อความสถานะหน้า
    const invoiceRows = document.getElementById("invoiceRows");
    const repairList = document.getElementById("repairList");
    const dashboardMessage = document.getElementById("dashboardMessage");
    // ! คือไม่พบ; || คืออย่างใดอย่างหนึ่ง; ขาดจุดหลักก็หยุดด้วย return ไม่ใช่ปิดทั้งเว็บ
    if (!totalRooms || !availableRooms || !activeTenants || !overdueBills || !invoiceRows || !repairList) {
        return;
    }
    // function รวมงานสร้างป้ายสถานะบิล ใช้ซ้ำกับหลายบิล
    function createInvoiceStatus(status) {
        // String แปลงเป็นข้อความ; || "" ใช้ข้อความว่างเมื่อไม่มีค่า; toUpperCase ทำตัวใหญ่ก่อนเทียบ
        const value = String(status || "").toUpperCase();
        // createElement สร้าง span ในหน่วยความจำ ยังไม่ขึ้นจอจน appendChild
        const badge = document.createElement("span");
        // === ตรวจค่าและชนิด; if/else if/else เลือกป้ายตามสถานะ
        if (value === "PAID") {
            // className กำหนด class ทั้งชุด; badge ทำป้าย; text-bg-success ให้พื้นเขียวพร้อมข้อความ
            badge.className = "badge text-bg-success";
            // textContent แสดงข้อความธรรมดา ไม่ทำงานเป็น HTML
            badge.textContent = "ชำระแล้ว";
        } else if (value === "PARTIAL") {
            badge.className = "badge text-bg-warning";
            badge.textContent = "ชำระบางส่วน";
        // โค้ดเดิมจัดสถานะที่ไม่ใช่ PAID/PARTIAL เป็นยังไม่ชำระ จึงควรเพิ่มกรณีเมื่อมีสถานะใหม่
        } else {
            badge.className = "badge text-bg-danger";
            badge.textContent = "ยังไม่ชำระ";
        }
        // return คืนชิ้น span ให้ผู้เรียกนำไปใส่ช่องตาราง
        return badge;
    }
    // renderInvoices วาดตารางบนหน้าเว็บ ไม่ได้สร้างบิลในฐานข้อมูล
    function renderInvoices(invoices) {
        // replaceChildren ลบแถวเดิมบนจอ ไม่ใช่ DELETE บิล
        invoiceRows.replaceChildren();
        // length คือจำนวนรายการ; ไม่มีรายการจึงสร้างแถวข้อความ
        if (invoices.length === 0) {
            // insertRow เพิ่ม tr; insertCell เพิ่ม td; colSpan=4 รวมสี่คอลัมน์
            const row = invoiceRows.insertRow();
            const cell = row.insertCell();
            cell.colSpan = 4;
            cell.className = "text-center text-muted py-4";
            cell.textContent = "ยังไม่มีข้อมูลบิล";
            return;
        }
        // forEach วนบิลทีละรายการ; invoice => คือฟังก์ชันสั้นรับบิลหนึ่งใบ
        invoices.forEach(invoice => {
            const row = invoiceRows.insertRow();
            // || "—" แสดงขีดแทนค่าที่ไม่มี; จุดใน invoice.room_number อ่านชื่อข้อมูลจาก JSON
            row.insertCell().textContent = invoice.room_number || "—";
            row.insertCell().textContent = invoice.tenant_name || "—";
            const amountCell = row.insertCell();
            // total_amount คือยอดทั้งบิล; Number แปลงเป็นเลข; toLocaleString จัดคอมมา/ทศนิยม ไม่ใช่การคิดยอดชำระ
            amountCell.textContent = Number(invoice.total_amount || 0).toLocaleString("th-TH", {
                // กำหนดให้แสดงทศนิยมอย่างน้อยและไม่เกินสองหลัก จึงได้สองหลักเสมอ
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
            // สร้างป้ายจาก payment_status แล้ว appendChild ใส่ลง td
            row.insertCell().appendChild(createInvoiceStatus(invoice.payment_status));
        });
    }
    // คืนคู่ข้อความไทยและ class สีสถานะงานซ่อม ไม่ใช่ความเร่งด่วน
    function getRepairStatus(status) {
        const value = String(status || "").toUpperCase();
        if (value === "PENDING") {
            // [...] คือ Array ของสองค่า ไม่ใช่การเข้าถึง field แบบ object[ชื่อ]
            return ["รอดำเนินการ", "text-bg-warning"];
        }
        if (value === "IN_PROGRESS") {
            return ["กำลังดำเนินการ", "text-bg-primary"];
        }
        if (value === "COMPLETED") {
            return ["เสร็จสิ้น", "text-bg-success"];
        }
        if (value === "CANCELLED") {
            return ["ยกเลิก", "text-bg-secondary"];
        }
        // สถานะที่ยังไม่รู้จักแสดงข้อความเดิมด้วยสีเทา แทนการเดาว่าเสร็จแล้ว
        return [status || "—", "text-bg-secondary"];
    }
    // แปล priority ความเร่งด่วน แยกจาก status ที่บอกว่างานทำถึงขั้นไหน
    function getPriority(priority) {
        const value = String(priority || "").toUpperCase();
        if (value === "URGENT") {
            return "เร่งด่วนมาก";
        }
        if (value === "HIGH") {
            return "เร่งด่วน";
        }
        if (value === "NORMAL") {
            return "ปกติ";
        }
        if (value === "LOW") {
            return "ต่ำ";
        }
        return priority || "—";
    }
    // ล้างและสร้างรายการซ่อมใน repairList จากข้อมูล API
    function renderRepairs(repairs) {
        repairList.replaceChildren();
        // ไม่มีรายการที่ API เลือกมา ไม่ได้แปลว่าฐานข้อมูลไม่มีประวัติซ่อมที่เสร็จแล้ว
        if (repairs.length === 0) {
            const message = document.createElement("p");
            message.className = "text-center text-muted py-4 mb-0";
            message.textContent = "ไม่มีรายการแจ้งซ่อมที่กำลังดำเนินการ";
            // appendChild ต่อชิ้นข้อความเข้าไปจึงเห็นบนจอ
            repairList.appendChild(message);
            return;
        }
        // แต่ละงานซ่อมสร้าง div ใหญ่และกล่องรายละเอียด; class repair-item ใช้ CSS เดิม
        repairs.forEach(repair => {
            const item = document.createElement("div");
            item.className = "repair-item";
            const detail = document.createElement("div");
            // strong ทำข้อความเน้นสำคัญ; span แสดงคำอธิบายสั้นด้านล่าง
            const title = document.createElement("strong");
            const info = document.createElement("span");
            // backtick เติม ${...} เป็นข้อความได้; getPriority แปลรหัสความเร่งด่วนเป็นคำอ่าน
            title.textContent = `ห้อง ${repair.room_number || "—"} - ${repair.title || "—"}`;
            info.textContent = `${repair.request_number || "—"} • ${getPriority(repair.priority)}`;
            detail.appendChild(title);
            detail.appendChild(info);
            // [statusText, statusClass] แยกสองค่าที่ฟังก์ชันคืนมาไปเก็บคนละตัวแปร
            const [statusText, statusClass] = getRepairStatus(repair.status);
            const badge = document.createElement("span");
            badge.className = `badge ${statusClass}`;
            badge.textContent = statusText;
            // ต่อรายละเอียดและป้ายลง item แล้วต่อ item ลงรายการหลัก ลำดับนี้สร้างโครง HTML ด้วย JS
            item.appendChild(detail);
            item.appendChild(badge);
            repairList.appendChild(item);
        });
    }
    // เมื่อโหลดผิดพลาดให้จำนวนเป็นขีด แทนแสดงศูนย์เหมือนอ่านฐานข้อมูลสำเร็จ
    function showError(message) {
        totalRooms.textContent = "—";
        availableRooms.textContent = "—";
        activeTenants.textContent = "—";
        overdueBills.textContent = "—";
        // innerHTML ตีความข้อความเป็นแท็ก ต่างจาก textContent ที่ใส่ข้อความธรรมดา
        // ข้อควรระวังของโค้ดเดิม: ไม่ควรนำข้อความที่ไม่น่าเชื่อถือมาต่อใน innerHTML; งานจริงควรสร้าง td/p แล้วใช้ textContent
        invoiceRows.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger py-4">${message}</td>
            </tr>
        `;
        repairList.innerHTML = `
            <p class="text-center text-danger py-4 mb-0">${message}</p>
        `;
        // dashboardMessage อาจไม่มี จึงตรวจก่อน; classList.add เพิ่มสีแดงโดยไม่ทับ class อื่น
        if (dashboardMessage) {
            dashboardMessage.textContent = message;
            dashboardMessage.classList.add("text-danger");
        }
    }
    // async ประกาศงานที่รอผลได้; loadDashboard เป็นชื่อที่เราเขียนเอง
    async function loadDashboard() {
        if (dashboardMessage) {
            // เปลี่ยนข้อความระหว่างรอ และ remove สี error เก่าก่อนลองใหม่
            dashboardMessage.textContent = "กำลังโหลดข้อมูลจากฐานข้อมูล...";
            dashboardMessage.classList.remove("text-danger");
        }
        // try/catch รับข้อผิดพลาดตอนติดต่อหรือแสดงข้อมูล
        try {
            // fetch เรียก /api/owner/dashboard; await รอผลในฟังก์ชันนี้ ไม่ได้เชื่อมฐานข้อมูลตรง
            const response = await fetch("/api/owner/dashboard", {
                // credentials same-origin แนบคุกกี้ Session ให้เว็บต้นทาง; cache no-store ไม่ใช้ผลเก่า
                credentials: "same-origin",
                cache: "no-store"
            });
            // json() อ่านคำตอบ; catch ใช้ {} ถ้าอ่านไม่ได้ เป็นพฤติกรรมเดิมที่ยังตรวจคำตอบไม่ครบ
            const data = await response.json().catch(() => ({}));
            // ok จริงเมื่อ HTTP 200–299; throw new Error ส่งข้อความไป catch
            if (!response.ok) {
                throw new Error(data.error || "โหลดข้อมูลหน้าหลักไม่สำเร็จ");
            }
            // ?? 0 ใช้ศูนย์เฉพาะเมื่อเป็น null/undefined ไม่เหมือน ||; โค้ดเดิมมีค่าสำรองนี้ จึงควรตรวจรูปแบบ API เพิ่ม
            totalRooms.textContent = data.total_rooms ?? 0;
            availableRooms.textContent = data.available_rooms ?? 0;
            activeTenants.textContent = data.active_tenants ?? 0;
            overdueBills.textContent = data.overdue_bills ?? 0;
            // data.invoices และ data.repairs เป็น Array; || [] ใช้รายการว่างเมื่อไม่มีค่า
            renderInvoices(data.invoices || []);
            renderRepairs(data.repairs || []);
            // ข้อความนี้ตั้งเมื่อโค้ดฝั่ง try ทำครบ ไม่ได้เป็นหลักฐานแยกว่าคำตอบผิดรูปแบบจะถูกจับทุกกรณี
            if (dashboardMessage) {
                dashboardMessage.textContent = "ข้อมูลจากฐานข้อมูล PostgreSQL";
            }
        // catch เรียก showError แสดงปัญหาแทนข้อมูล
        } catch (error) {
            showError(error.message);
        }
    }
    // เรียกฟังก์ชันจริงหนึ่งครั้งเมื่อเปิดหน้า ไม่ได้ตั้งเวลาโหลดซ้ำอัตโนมัติ
    loadDashboard();
})();
